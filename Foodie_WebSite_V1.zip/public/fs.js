var configuration={
  apiKey: "AIzaSyCEEU5Ky0SXPckGPLMBP27zlbNttuwPR4k",
  authDomain: "foodies-3c1d9.firebaseapp.com",
  databaseURL: "https://foodies-3c1d9-default-rtdb.firebaseio.com",
  projectId: "foodies-3c1d9",
  storageBucket: "foodies-3c1d9.appspot.com",
  messagingSenderId: "275231286183",
  appId: "1:275231286183:web:b2a20286b8df80499d0c82",
  measurementId: "G-KTWQ93G1PT"
};