<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from askbootstrap.com/preview/swiggiweb/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 Jan 2022 10:58:44 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Askbootstrap">
<meta name="author" content="Askbootstrap">
<link rel="icon" type="image/png" href="img/fav.png">
<title>Swiggiweb - Online Food Ordering Website Template</title>

<link rel="stylesheet" type="text/css" href="vendor/slick/slick.min.css" />
<link rel="stylesheet" type="text/css" href="vendor/slick/slick-theme.min.css" />

<link href="vendor/icons/feather.css" rel="stylesheet" type="text/css">

<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<link href="css/style.css" rel="stylesheet">

<link href="vendor/sidebar/demo.css" rel="stylesheet">
</head>
<body>
<div class="login-page vh-100">
<video loop autoplay muted id="vid">
<source src="img/bg.mp4" type="video/mp4">
<source src="img/bg.mp4" type="video/ogg">
Your browser does not support the video tag.
</video>
<div class="d-flex align-items-center justify-content-center vh-100">
<div class="px-5 col-md-6 ml-auto">
<div class="px-5 col-10 mx-auto">
<h2 class="text-dark my-0">Welcome Back</h2>
<p class="text-50">Sign in to continue</p>
<form class="mt-5 mb-4" action="https://askbootstrap.com/preview/swiggiweb/verification.html">
<div class="form-group">
<label for="exampleInputEmail1" class="text-dark">Email</label>
<input type="email" placeholder="Enter Email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
</div>
<div class="form-group">
<label for="exampleInputPassword1" class="text-dark">Password</label>
<input type="password" placeholder="Enter Password" class="form-control" id="exampleInputPassword1">
</div>
<button class="btn btn-primary btn-lg btn-block">SIGN IN</button>
<div class="py-2">
<button class="btn btn-lg btn-facebook btn-block"><i class="feather-facebook"></i> Connect with Facebook</button>
</div>
</form>
<a href="forgot_password.html" class="text-decoration-none">
<p class="text-center">Forgot your password?</p>
</a>
<div class="d-flex align-items-center justify-content-center">
<a href="signup.html">
<p class="text-center m-0">Don't have an account? Sign up</p>
</a>
</div>
</div>
</div>
</div>
</div>
<nav id="main-nav">
<ul class="second-nav">
<li><a href="home.html"><i class="feather-home mr-2"></i> Homepage</a></li>
<li><a href="my_order.html"><i class="feather-list mr-2"></i> My Orders</a></li>
<li>
<a href="#"><i class="feather-edit-2 mr-2"></i> Authentication</a>
<ul>
<li><a href="login.html">Login</a></li>
<li><a href="signup.html">Register</a></li>
<li><a href="forgot_password.html">Forgot Password</a></li>
<li><a href="verification.html">Verification</a></li>
<li><a href="location.html">Location</a></li>
</ul>
</li>
<li><a href="favorites.html"><i class="feather-heart mr-2"></i> Favorites</a></li>
<li><a href="trending.html"><i class="feather-trending-up mr-2"></i> Trending</a></li>
<li><a href="most_popular.html"><i class="feather-award mr-2"></i> Most Popular</a></li>
<li><a href="restaurant.html"><i class="feather-paperclip mr-2"></i> Restaurant Detail</a></li>
<li><a href="checkout.html"><i class="feather-list mr-2"></i> Checkout</a></li>
<li><a href="successful.html"><i class="feather-check-circle mr-2"></i> Successful</a></li>
<li><a href="map.html"><i class="feather-map-pin mr-2"></i> Live Map</a></li>
<li>
<a href="#"><i class="feather-user mr-2"></i> Profile</a>
<ul>
<li><a href="profile.html">Profile</a></li>
<li><a href="favorites.html">Delivery support</a></li>
<li><a href="contact-us.html">Contact Us</a></li>
<li><a href="terms.html">Terms of use</a></li>
<li><a href="privacy.html">Privacy & Policy</a></li>
</ul>
</li>
<li>
<a href="#"><i class="feather-alert-triangle mr-2"></i> Error</a>
<ul>
<li><a href="not-found.html">Not Found</a>
<li><a href="maintence.html"> Maintence</a>
<li><a href="coming-soon.html">Coming Soon</a>
</ul>
</li>
<li>
<a href="#"><i class="feather-link mr-2"></i> Navigation Link Example</a>
<ul>
<li>
<a href="#">Link Example 1</a>
<ul>
<li>
<a href="#">Link Example 1.1</a>
<ul>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
</ul>
</li>
<li>
<a href="#">Link Example 1.2</a>
<ul>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
</ul>
</li>
</ul>
</li>
<li><a href="#">Link Example 2</a></li>
<li><a href="#">Link Example 3</a></li>
<li><a href="#">Link Example 4</a></li>
<li data-nav-custom-content>
<div class="custom-message">
You can add any custom content to your navigation items. This text is just an example.
</div>
</li>
</ul>
</li>
</ul>
<ul class="bottom-nav">
<li class="email">
<a class="text-danger" href="home.html">
<p class="h5 m-0"><i class="feather-home text-danger"></i></p>
Home
</a>
</li>
<li class="github">
<a href="faq.html">
<p class="h5 m-0"><i class="feather-message-circle"></i></p>
FAQ
</a>
</li>
<li class="ko-fi">
<a href="contact-us.html">
<p class="h5 m-0"><i class="feather-phone"></i></p>
Help
</a> 
</li>
</ul>
</nav>

<script type="3278c391769b1424e162b7fa-text/javascript" src="vendor/jquery/jquery.min.js"></script>
<script type="3278c391769b1424e162b7fa-text/javascript" src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script type="3278c391769b1424e162b7fa-text/javascript" src="vendor/slick/slick.min.js"></script>

<script type="3278c391769b1424e162b7fa-text/javascript" src="vendor/sidebar/hc-offcanvas-nav.js"></script>

<script type="3278c391769b1424e162b7fa-text/javascript" src="js/osahan.js"></script>
<script src="js/rocket-loader.min.js" data-cf-settings="3278c391769b1424e162b7fa-|49" defer=""></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6c83f36faf1273c7","version":"2021.12.0","r":1,"token":"dd471ab1978346bbb991feaa79e6ce5c","si":100}' crossorigin="anonymous"></script>
</body>

<!-- Mirrored from askbootstrap.com/preview/swiggiweb/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 Jan 2022 10:58:44 GMT -->
</html><?php /**PATH D:\php\htdocs\laravelpro\resources\views/login\login.blade.php ENDPATH**/ ?>