
 <?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="siddhi-profile">
<div class="d-none">
<div class="bg-primary border-bottom p-3 d-flex align-items-center">
<a class="toggle togglew toggle-2" href="#"><span></span></a>
<h4 class="font-weight-bold m-0 text-white">Profile</h4>
</div>
</div>

<div class="container position-relative">
<div class="py-5 siddhi-profile row">
<div class="col-md-4 mb-3">
<div class="bg-white rounded shadow-sm sticky_sidebar overflow-hidden">
<a href="profile.html" class="">
<div class="d-flex align-items-center p-3">
<div class="left mr-3">
<img alt="#" src="<?php echo e(asset('img/user1.jpg')); ?>" class="rounded-circle">
</div>
<div class="right">
<h6 class="mb-1 font-weight-bold">Gurdeep Singh <i class="feather-check-circle text-success"></i></h6>
<p class="text-muted m-0 small"><span class="__cf_email__" data-cfemail="264f474b4955474e474866414b474f4a0845494b">[email&#160;protected]</span></p>
</div>
</div>
</a>
<div class="siddhi-credits d-flex align-items-center p-3 bg-light">
<p class="m-0">Accounts Credits</p>
<h5 class="m-0 ml-auto text-primary">$52.25</h5>
</div>

<div class="bg-white profile-details">
<a data-toggle="modal" data-target="#paycard" class="d-flex w-100 align-items-center border-bottom p-3">
<div class="left mr-3">
<h6 class="font-weight-bold mb-1 text-dark">Payment Cards</h6>
<p class="small text-muted m-0">Add a credit or debit card</p>
</div>
<div class="right ml-auto">
<h6 class="font-weight-bold m-0"><i class="feather-chevron-right"></i></h6>
</div>
</a>
<a data-toggle="modal" data-target="#exampleModal" class="d-flex w-100 align-items-center border-bottom p-3">
<div class="left mr-3">
<h6 class="font-weight-bold mb-1 text-dark">Address</h6>
<p class="small text-muted m-0">Add or remove a delivery address</p>
</div>
<div class="right ml-auto">
<h6 class="font-weight-bold m-0"><i class="feather-chevron-right"></i></h6>
</div>
</a>
<a class="d-flex align-items-center border-bottom p-3" data-toggle="modal" data-target="#inviteModal">
<div class="left mr-3">
<h6 class="font-weight-bold mb-1">Refer Friends</h6>
<p class="small text-primary m-0">Get $10.00 FREE</p>
</div>
<div class="right ml-auto">
<h6 class="font-weight-bold m-0"><i class="feather-chevron-right"></i></h6>
</div>
</a>
<a href="faq.html" class="d-flex w-100 align-items-center border-bottom px-3 py-4">
<div class="left mr-3">
<h6 class="font-weight-bold m-0 text-dark"><i class="feather-truck bg-danger text-white p-2 rounded-circle mr-2"></i> Delivery Support</h6>
</div>
<div class="right ml-auto">
<h6 class="font-weight-bold m-0"><i class="feather-chevron-right"></i></h6>
</div>
</a>
<a href="contact-us.html" class="d-flex w-100 align-items-center border-bottom px-3 py-4">
<div class="left mr-3">
<h6 class="font-weight-bold m-0 text-dark"><i class="feather-phone bg-primary text-white p-2 rounded-circle mr-2"></i> Contact</h6>
</div>
<div class="right ml-auto">
<h6 class="font-weight-bold m-0"><i class="feather-chevron-right"></i></h6>
</div>
</a>
<a href="terms.html" class="d-flex w-100 align-items-center border-bottom px-3 py-4">
<div class="left mr-3">
<h6 class="font-weight-bold m-0 text-dark"><i class="feather-info bg-success text-white p-2 rounded-circle mr-2"></i> Term of use</h6>
</div>
<div class="right ml-auto">
<h6 class="font-weight-bold m-0"><i class="feather-chevron-right"></i></h6>
</div>
</a>
<a href="privacy.html" class="d-flex w-100 align-items-center px-3 py-4">
<div class="left mr-3">
<h6 class="font-weight-bold m-0 text-dark"><i class="feather-lock bg-warning text-white p-2 rounded-circle mr-2"></i> Privacy policy</h6>
</div>
<div class="right ml-auto">
<h6 class="font-weight-bold m-0"><i class="feather-chevron-right"></i></h6>
</div>
</a>
</div>
</div>
</div>
<div class="col-md-8 mb-3">
<div class="rounded shadow-sm">
<div class="siddhi-cart-item-profile bg-white rounded shadow-sm p-4">
<div class="flex-column">
 <h6 class="font-weight-bold">Tell us about yourself</h6>
<p class="text-muted">Whether you have questions or you would just like to say hello, contact us.</p>
<form>
<div class="form-group">
<label for="exampleFormControlInput1" class="small font-weight-bold">Your Name</label>
<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Gurdeep siddhi">
</div>
<div class="form-group">
<label for="exampleFormControlInput2" class="small font-weight-bold">Email Address</label>
<input type="email" class="form-control" id="exampleFormControlInput2" placeholder="iamsiddhi@gmail.com">
</div>
<div class="form-group">
<label for="exampleFormControlInput3" class="small font-weight-bold">Phone Number</label>
<input type="number" class="form-control" id="exampleFormControlInput3" placeholder="1-800-643-4500">
</div>
<div class="form-group">
<label for="exampleFormControlTextarea1" class="small font-weight-bold">HOW CAN WE HELP YOU?</label>
<textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Hi there, I would like to ..." rows="3"></textarea>
</div>
<a class="btn btn-primary btn-block" href="#">SUBMIT</a>
</form>

<div class="mapouter pt-3">
<div class="gmap_canvas"><iframe width="100%" height="100%" id="gmap_canvas" src="https://maps.google.com/maps?q=dugri%20ludhiana&amp;t=&amp;z=13&amp;ie=UTF8&amp;iwloc=&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="3d9fa72af2be5f5f8c3d5a7d-text/javascript" src="vendor/jquery/jquery.min.js"></script>
<script type="3d9fa72af2be5f5f8c3d5a7d-text/javascript" src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script type="3d9fa72af2be5f5f8c3d5a7d-text/javascript" src="vendor/slick/slick.min.js"></script>

<script type="3d9fa72af2be5f5f8c3d5a7d-text/javascript" src="vendor/sidebar/hc-offcanvas-nav.js"></script>

<script type="3d9fa72af2be5f5f8c3d5a7d-text/javascript" src="js/siddhi.js"></script>
<script src="js/rocket-loader.min.js" data-cf-settings="3d9fa72af2be5f5f8c3d5a7d-|49" defer=""></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6c83f3779a1873c7","version":"2021.12.0","r":1,"token":"dd471ab1978346bbb991feaa79e6ce5c","si":100}' crossorigin="anonymous"></script>
<?php /**PATH /home/foodie/public_html/website/resources/views/contact_us/contact_us.blade.php ENDPATH**/ ?>