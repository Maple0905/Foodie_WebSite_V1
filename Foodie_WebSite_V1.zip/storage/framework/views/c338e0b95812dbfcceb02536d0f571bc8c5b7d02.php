				
				<?php if(@$order_complete){ ?>
					<div class="d-flex border-bottom siddhi-cart-item-profile bg-white p-3">
						<p>Your order has been placed successfully</p>
					</div>
				<?php } ?>
				<?php if(@$cart['restaurant']['id']){  ?>
							<div class="d-flex border-bottom siddhi-cart-item-profile bg-white p-3">
								<img alt="siddhi" src="<?php echo @$cart['restaurant']['image']; ?>" class="mr-3 rounded-circle img-fluid">
								<div class="d-flex flex-column mt-3">
									<h6 class="mb-1 font-weight-bold"><?php echo @$cart['restaurant']['name']; ?></h6>
									<p class="mb-0 small text-muted">
										<i class="feather-map-pin"></i> <?php echo @$cart['restaurant']['location']; ?>
									</p>
								</div>
							</div>
				<?php }else{ ?>

					<div class="d-flex border-bottom siddhi-cart-item-profile bg-white p-3" id="restaurant_place" style="display: none;">
						<img alt="siddhi" id="restaurant_image_place" src="" style="display:none;" class="mr-3 rounded-circle img-fluid">
						<div class="d-flex flex-column mt-3">
							<h6 class="mb-1 font-weight-bold" id="restaurant_name_place"></h6>
							<p class="mb-0 small text-muted" id="restaurant_location_place">
								<i class="feather-map-pin"></i>
							</p>
						</div>
					</div>

				<?php } ?>	
			<?php $item_count=0; $total_price=0;  if(@$cart['item']){ foreach ($cart['item'] as $key => $value_restaurant) {  $item_count++; ?>
				<div class="bg-white border-bottom py-2">
				<input type="hidden" name="main_restaurant_id" value="<?php echo @$key; ?>" id="main_restaurant_id">
					<?php foreach ($value_restaurant as $key1 => $value_item) { ?>

				<div class="product-item gold-members d-flex align-items-center justify-content-between px-3 py-2 border-bottom" id="item_<?php echo @$key1; ?>" data-id="<?php echo @$key1; ?>">
					<input type="hidden" id="price_<?php echo @$key1; ?>" value="<?php echo $value_item['price']+@$value_item['extra_price']; ?>">

					<input type="hidden" id="photo_<?php echo @$key1; ?>" value="<?php echo $value_item['image']; ?>">
					<input type="hidden" id="name_<?php echo @$key1; ?>" value="<?php echo $value_item['name']; ?>">
					<input type="hidden" id="quantity_<?php echo @$key1; ?>" value="<?php echo $value_item['quantity']; ?>">
										<div class="media align-items-center">
											<div class="mr-2 text-danger">
												&middot;
											</div>
											<div class="media-body">
												<p class="m-0">
													<?php echo $value_item['name']; ?>
												</p>
												<?php if(@$value_item['extra']){ ?>
													<div class="extras">
													<span>Extra</span>
													<?php foreach ($value_item['extra'] as $key3 => $extra) { ?>
													<input type="hidden" class="extras_<?php echo @$key1; ?>" value="<?php echo $extra; ?>">
														<p><?php echo $extra; ?></p>
													<?php } ?>
													</div> 
												<?php } ?>
												<input type="hidden" id="extras_price_<?php echo @$key1; ?>" value="<?php echo @$value_item['extra_price']; ?>">
												<?php if(@$value_item['size']){ ?>
													<div class="size">
													<span>Size</span>
														<p><?php echo $value_item['size']; ?></p>
													</div>
												<?php } ?>
												<input type="hidden" id="size_<?php echo @$key1; ?>" value="<?php echo @$value_item['size']; ?>">
											</div>

										</div>
										<div class="d-flex align-items-center">
											<span class="count-number float-right">
												<button type="button" data-restaurant="<?php echo $key; ?>" data-id="<?php echo $key1; ?>" class="count-number-input-cart btn-sm left dec btn btn-outline-secondary">
													<i class="feather-minus"></i>
												</button>
												<input class="count-number-input count_number_<?php echo $key1; ?>"  type="text" readonly value="<?php echo $value_item['quantity']; ?>">
												<button type="button" data-restaurant="<?php echo $key; ?>" data-id="<?php echo $key1; ?>" class="count-number-input-cart btn-sm right inc btn btn-outline-secondary">
													<i class="feather-plus"></i>
												</button></span>
											<p class="text-gray mb-0 float-right ml-2 text-muted small">
												$<?php echo @$value_item['price']+@$value_item['extra_price']; ?>
											</p>
										</div>
										<div class="close remove_item" data-restaurant="<?php echo $key; ?>" data-id="<?php echo $key1; ?>"><i class="fa fa-trash"></i></div>
									</div>
									<?php $total_price=$total_price+($value_item['price']+@$value_item['extra_price']); } ?>

							<?php } ?> 
							</div>

							<div class="bg-white p-3 py-3 border-bottom clearfix">
								<div class="input-group-sm mb-2 input-group">
									<input placeholder="Enter promo code" data-restaurant="<?php echo @$key1; ?>" value="<?php echo @$cart['coupon']['coupon_code'] ?>" id="coupon_code" type="text" class="form-control">
									<div class="input-group-append">
										<button type="button" class="btn btn-primary"  id="apply-coupon-code">
											<i class="feather-percent"></i> APPLY
										</button>
									</div>
								</div>
								<!-- <div class="mb-0 input-group">
									<div class="input-group-prepend">
										<span class="input-group-text"><i class="feather-message-square"></i></span>
									</div>
									<textarea placeholder="Any suggestions? We will pass it on..." aria-label="With textarea" class="form-control"></textarea>
								</div> -->
							</div>

							<?php  } ?>
							
						<?php if($item_count==0){ ?>
							<div class="bg-white border-bottom py-2">
								<div class="gold-members d-flex align-items-center justify-content-between px-3 py-2 border-bottom"><span>Your Cart is Empty</span>
								</div>
							</div>
						<?php } ?>
				<?php 
				if(@$cart['tip_amount']){
					$tip_amount=$cart['tip_amount'];
				}else{
					$tip_amount='';
				}
				?>

				<div class="bg-white p-3 clearfix border-bottom delivery-box">
						<h3>Delivery Option</h3>
						<div class="delevery-option">
							<div class="custom-control custom-radio border-bottom py-2">
					            <input type="radio" name="delivery_option" id="delivery" value="delivery" class="this_delivery_option custom-control-input" <?php if(@$cart['delivery_option']!="takeaway"){ ?> checked <?php } ?>>
					            <label class="custom-control-label" for="delivery">Delivery($<?php echo @$cart['deliverychargemain']; ?>)</label>
					        </div>
					        <div class="custom-control custom-radio border-bottom py-2">
					            <input type="radio" name="delivery_option" id="takeaway" value="takeaway" class="this_delivery_option custom-control-input" <?php if(@$cart['delivery_option']=="takeaway"){ ?> checked <?php } ?>>
					            <label class="custom-control-label" for="takeaway">Takeaway(Free)</label>
					        </div>
						</div>
				</div>	

				<div class="bg-white p-3 clearfix border-bottom delevery-partner" style="<?php if(@$cart['delivery_option']=="takeaway"){ ?> display:none; <?php } ?>">
						<h3>Tip Your delivery partner</h3>
						<span class="float-center">100% of the tip go to your delivery partner</span>
						<div class="tip-box">
							<div class="custom-control custom-radio border-bottom py-2">
					            <input type="radio" name="tip" id="10" value="10" class="this_tip custom-control-input" <?php if(@$tip_amount==10){ ?> checked <?php } ?>>
					            <label class="custom-control-label" for="10">$10</label>
					        </div>
					        <div class="custom-control custom-radio border-bottom py-2">
					            <input type="radio" name="tip" id="20" value="20" class="this_tip custom-control-input" <?php if(@$tip_amount==20){ ?> checked <?php } ?>>
					            <label class="custom-control-label" for="20">$20</label>
					        </div>
					        <div class="custom-control custom-radio border-bottom py-2">
					            <input type="radio" name="tip" id="30" value="30" class="this_tip custom-control-input" <?php if(@$tip_amount==30){ ?> checked <?php } ?>>
					            <label class="custom-control-label" for="30">$30</label>
					        </div>
					        <div class="custom-control custom-radio border-bottom py-2">
					            <input type="radio" name="tip" id="Other_tip" value="Other" class="custom-control-input" <?php if($tip_amount && (@$tip_amount!=10 && @$tip_amount!=20 && @$tip_amount!=30)){ ?> checked <?php } ?>>
					            <label class="custom-control-label" for="Other_tip">Other</label>
					        </div>
					        <div class="custom-control custom-radio border-bottom py-2" style="display: none;" id="add_tip_box">
					        	<input type="number" name="tip_amount" id="tip_amount" value="<?php echo @$cart['tip_amount']; ?>">
					        </div>
					        
						</div>
					</div>	
				
				<div class="bg-white p-3 clearfix border-bottom">
					<p class="mb-1">
						Item Total <span class="float-right text-dark">$<?php echo $total_price; ?></span>
					</p>
					<?php if($item_count && $tip_amount){ $total_price=$total_price+$tip_amount; ?>
						<p class="mb-1">
							Tip Amount <span class="float-right text-dark">$<?php echo $tip_amount; ?></span>
						</p>
					<?php } ?>

					<?php if($item_count && @$cart['deliverycharge']){ ?>
						<?php  $total_price=$total_price+$cart['deliverycharge']; ?>
						<p class="mb-1">
							Delivery Charge <span class="float-right text-dark">$<?php echo @$cart['deliverycharge']; ?></span>
						</p>
					<?php } ?>
					<input type="hidden" value="<?php echo @$cart['deliverycharge']; ?>" id="deliveryCharge">
					<input type="hidden" value="<?php echo @$cart['deliverychargemain']; ?>" id="deliveryChargeMain">
					<input type="hidden" id="adminCommission" value="0">
					<!-- <p class="mb-1">
						Delivery Fee<span class="text-info ml-1"><i class="feather-info"></i></span><span class="float-right text-dark">$10</span>
					</p> -->
					<!-- <p class="mb-1 text-success">
						Total Discount<span class="float-right text-success">$1884</span>
					</p> -->

					<?php  $discount_amount=0; $coupon_id=''; $coupon_code=''; $discount=''; $discountType=''; if(@$cart['coupon'] && $cart['coupon']['discountType']){ ?>
						<p class="mb-1 text-success">
							<?php $discountType=$cart['coupon']['discountType'];
								  $coupon_code=$cart['coupon']['coupon_code'];
								  $coupon_id=@$cart['coupon']['coupon_id'];
								  $discount=$cart['coupon']['discount'];
								if($discountType=="Fix Price"){
									$discount_amount=$cart['coupon']['discount'];	
								  	$total=$total_price-$discount_amount;
								  	if($discount_amount>$total){
										$discount_amount=$total;
									}
									if($total<0){
										$total=0;
									}
								}else{
									$discount_amount=$cart['coupon']['discount'];	
									$discount_amount=($total_price*$discount_amount)/100;
									$total=$total_price-$discount_amount;
									if($discount_amount>$total){
										$discount_amount=$total;
									}
									if($total<0){
										$total=0;
									}
								}

							 ?>
							Total Discount<span class="float-right text-success">$<?php echo $discount_amount; ?></span>
						</p>
					<?php }else{ ?>
							<?php $total=$total_price; ?>
					<?php } ?>
					<hr>
					<input type="hidden"  id="discount_amount" value="<?php echo $discount_amount; ?>">
					<input type="hidden"  id="coupon_id" value="<?php echo $coupon_id; ?>">
					<input type="hidden"  id="coupon_code_main" value="<?php echo $coupon_code; ?>">
					<input type="hidden"  id="discount" value="<?php echo $discount; ?>">
					<input type="hidden"  id="discountType" value="<?php echo $discountType; ?>">
					<input type="hidden"  id="total_pay" value="<?php echo $total; ?>">
					<h6 class="font-weight-bold mb-0">TO PAY <span class="float-right">$<?php echo $total; ?></span></h6>
				</div>
				<div class="p-3">
					<?php if($item_count==0){ ?>
						<a class="btn btn-success btn-block btn-lg disable" href="javascript:void(0)">PAY $<?php echo $total; ?><i class="feather-arrow-right"></i></a>	
					<?php }else if(@$is_checkout){ ?>
						<a class="btn btn-success btn-block btn-lg" href="javascript:void(0)" onclick="finalCheckout()">PAY $<?php echo $total_price; ?><i class="feather-arrow-right"></i></a>
					<?php }else{ ?>
						<a class="btn btn-success btn-block btn-lg" href="<?php echo e(route('checkout')); ?>">PAY $<?php echo $total; ?><i class="feather-arrow-right"></i></a>
					<?php } ?>
				</div><?php /**PATH /home/foodie/public_html/website/resources/views/restaurant/cart_item.blade.php ENDPATH**/ ?>