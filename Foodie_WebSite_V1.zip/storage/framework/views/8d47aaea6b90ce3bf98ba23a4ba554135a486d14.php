<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from askbootstrap.com/preview/swiggiweb/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 Jan 2022 10:58:44 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Askbootstrap">
<meta name="author" content="Askbootstrap">
<link rel="icon" type="image/png" href="img/fav.png">
<title>Swiggiweb - Online Food Ordering Website Template</title>

<link rel="stylesheet" type="text/css" href="vendor/slick/slick.min.css" />
<link rel="stylesheet" type="text/css" href="vendor/slick/slick-theme.min.css" />

<link href="vendor/icons/feather.css" rel="stylesheet" type="text/css">

<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<link href="css/style.css" rel="stylesheet">

<link href="vendor/sidebar/demo.css" rel="stylesheet">
</head>
<body>
<div class="login-page vh-100">
<video loop autoplay muted id="vid">
<source src="<?php echo e(asset('img/bg.mp4')); ?>" type="video/mp4">
<source src="<?php echo e(asset('img/bg.mp4')); ?>" type="video/ogg">
Your browser does not support the video tag.
</video>
<div class="d-flex align-items-center justify-content-center vh-100">
<div class="px-5 col-md-6 ml-auto">
<div class="px-5 col-10 mx-auto">
<h2 class="text-dark my-0">Welcome Back</h2>
<p class="text-50">Sign in to continue</p>
<form class="mt-5 mb-4" action="https://askbootstrap.com/preview/swiggiweb/verification.html">
<div class="form-group">
<label for="exampleInputEmail1" class="text-dark">Email</label>
<input type="email" placeholder="Enter Email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
</div>
<div class="form-group">
<label for="exampleInputPassword1" class="text-dark">Password</label>
<input type="password" placeholder="Enter Password" class="form-control" id="exampleInputPassword1">
</div>
<button class="btn btn-primary btn-lg btn-block">SIGN IN</button>
<div class="py-2">
<button class="btn btn-lg btn-facebook btn-block"><i class="feather-facebook"></i> Connect with Facebook</button>
</div>
</form>
<a href="forgot_password.html" class="text-decoration-none">
<p class="text-center">Forgot your password?</p>
</a>
<div class="d-flex align-items-center justify-content-center">
<a href="signup.html">
<p class="text-center m-0">Don't have an account? Sign up</p>
</a>
</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="3278c391769b1424e162b7fa-text/javascript" src="vendor/jquery/jquery.min.js"></script>
<script type="3278c391769b1424e162b7fa-text/javascript" src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script type="3278c391769b1424e162b7fa-text/javascript" src="vendor/slick/slick.min.js"></script>

<script type="3278c391769b1424e162b7fa-text/javascript" src="vendor/sidebar/hc-offcanvas-nav.js"></script>

<script type="3278c391769b1424e162b7fa-text/javascript" src="js/osahan.js"></script>
<script src="js/rocket-loader.min.js" data-cf-settings="3278c391769b1424e162b7fa-|49" defer=""></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6c83f36faf1273c7","version":"2021.12.0","r":1,"token":"dd471ab1978346bbb991feaa79e6ce5c","si":100}' crossorigin="anonymous"></script>
</body>

<!-- Mirrored from askbootstrap.com/preview/swiggiweb/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 Jan 2022 10:58:44 GMT -->
</html><?php /**PATH /home/foodie/public_html/website/resources/views/login/login.blade.php ENDPATH**/ ?>