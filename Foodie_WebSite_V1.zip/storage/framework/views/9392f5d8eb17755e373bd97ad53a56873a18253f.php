<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="siddhi-checkout">
<!-- <div class="d-none">
<div class="bg-primary border-bottom p-3 d-flex align-items-center">
<a class="toggle togglew toggle-2" href="#"><span></span></a>
<h4 class="font-weight-bold m-0 text-white">Checkout</h4>
</div>
</div> -->

<div class="container position-relative">
<div class="py-5 row">
<div class="col-md-8 mb-3">
<div>
<div class="siddhi-cart-item mb-3 rounded shadow-sm bg-white overflow-hidden">
<div class="siddhi-cart-item-profile bg-white p-3">
<div class="d-flex flex-column">
<h6 class="mb-3 font-weight-bold">Delivery Address</h6>
<div class="row">
<div class="custom-control col-lg-6 custom-radio mb-3 position-relative border-custom-radio" id="address_box" style="display: none;">
<input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input" checked>
<label class="custom-control-label w-100" for="customRadioInline1">
<div>
<div class="p-3 bg-white rounded shadow-sm w-100">
<div class="d-flex align-items-center mb-2">
<h6 class="mb-0">Address</h6>
<!-- <p class="mb-0 badge badge-success ml-auto"><i class="icofont-check-circled"></i> Default</p> -->
</div>
<p class="small text-muted m-0" id="line_1"></p>
<p class="small text-muted m-0" id="line_2">Redwood City, CA 94063</p>
</div>
<a href="#" data-toggle="modal" data-target="#exampleModalAddress" class="btn btn-block btn-light border-top">Edit</a>
</div>
</label>
</div>
<!-- <div class="custom-control col-lg-6 custom-radio position-relative border-custom-radio">
<input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
<label class="custom-control-label w-100" for="customRadioInline2">
<div>
<div class="p-3 rounded bg-white shadow-sm w-100">
<div class="d-flex align-items-center mb-2">
<h6 class="mb-0">Work</h6>
<p class="mb-0 badge badge-light ml-auto"><i class="icofont-check-circled"></i> Select</p>
</div>
<p class="small text-muted m-0">Model Town, Ludhiana</p>
<p class="small text-muted m-0">Punjab 141002, India</p>
</div>
<a href="#" data-toggle="modal" data-target="#exampleModalAddress" class="btn btn-block btn-light border-top">Edit</a>
</div>
</label>
</div> -->
</div>
<a id="add_address" class="btn btn-primary" href="#" data-toggle="modal" data-target="#exampleModalAddress" style="display: none;"> ADD NEW ADDRESS </a>
</div>
</div>
</div>
<div class="accordion mb-3 rounded shadow-sm bg-white overflow-hidden" id="accordionExample">

<!-- Card -->
<!-- <div class="siddhi-card bg-white border-bottom overflow-hidden">
<div class="siddhi-card-header" id="headingOne">
<h2 class="mb-0">
<button class="d-flex p-3 align-items-center btn btn-link w-100" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
<i class="feather-credit-card mr-3"></i> Credit/Debit Card
<i class="feather-chevron-down ml-auto"></i>
</button>
</h2>
</div>
<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
<div class="siddhi-card-body border-top p-3">
<h6 class="m-0">Add new card</h6>
<p class="small">WE ACCEPT <span class="siddhi-card ml-2 font-weight-bold">( Master Card / Visa Card / Rupay )</span></p>
<form>
<div class="form-row">
<div class="col-md-12 form-group">
<label class="form-label font-weight-bold small">Card number</label>
<div class="input-group">
<input placeholder="Card number" type="number" class="form-control">
<div class="input-group-append"><button type="button" class="btn btn-outline-secondary"><i class="feather-credit-card"></i></button></div>
</div>
</div>
<div class="col-md-8 form-group"><label class="form-label font-weight-bold small">Valid through(MM/YY)</label><input placeholder="Enter Valid through(MM/YY)" type="number" class="form-control"></div>
 <div class="col-md-4 form-group"><label class="form-label font-weight-bold small">CVV</label><input placeholder="Enter CVV Number" type="number" class="form-control"></div>
<div class="col-md-12 form-group"><label class="form-label font-weight-bold small">Name on card</label><input placeholder="Enter Card number" type="text" class="form-control"></div>
<div class="col-md-12 form-group mb-0">
<div class="custom-control custom-checkbox"><input type="checkbox" id="custom-checkbox1" class="custom-control-input"><label title="" type="checkbox" for="custom-checkbox1" class="custom-control-label small pt-1">Securely save this card for a faster checkout next time.</label></div>
</div>
</div>
</form>
</div>
</div>
</div> -->
<!-- End Card -->

<!-- Net Banking -->
<!-- <div class="siddhi-card bg-white border-bottom overflow-hidden">
<div class="siddhi-card-header" id="headingTwo">
<h2 class="mb-0">
<button class="d-flex p-3 align-items-center btn btn-link w-100" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
<i class="feather-globe mr-3"></i> Net Banking
<i class="feather-chevron-down ml-auto"></i>
</button>
</h2>
</div>
<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
<div class="siddhi-card-body border-top p-3">
<form>
<div class="btn-group btn-group-toggle w-100" data-toggle="buttons">
<label class="btn btn-outline-secondary active">
<input type="radio" name="options" id="option1" checked> HDFC
</label>
<label class="btn btn-outline-secondary">
<input type="radio" name="options" id="option2"> ICICI
</label>
<label class="btn btn-outline-secondary">
<input type="radio" name="options" id="option3"> AXIS
</label>
</div>
<hr>
<div class="form-row">
<div class="col-md-12 form-group mb-0">
<label class="form-label small font-weight-bold">Select Bank</label><br>
<select class="custom-select form-control">
<option>Bank</option>
<option>KOTAK</option>
<option>SBI</option>
<option>UCO</option>
</select>
</div>
</div>
</form>
</div>
</div>
</div> -->
<!-- END Net Banking -->

<div class="siddhi-card bg-white overflow-hidden checkout-payment-options">
    
        <div class="custom-control custom-radio border-bottom py-2">
            <input type="radio" name="payment_method" id="cod" value="cod" class="custom-control-input" checked>
            <label class="custom-control-label" for="cod">Cash on Delivery</label>
        </div>

        <div class="custom-control custom-radio border-bottom py-2" style="display:none;" id="razorpay_box">
            <input type="radio" name="payment_method" id="razorpay"  value="razorpay" class="custom-control-input">
            <label class="custom-control-label" for="razorpay">Razorpay</label>
            <input type="hidden" id="isEnabled">
            <input type="hidden" id="isSandboxEnabled">
            <input type="hidden" id="razorpayKey">
            <input type="hidden" id="razorpaySecret">
        </div>
        
        <div class="custom-control custom-radio border-bottom py-2" style="display:none;" id="stripe_box">
            <input type="radio" name="payment_method" id="stripe"  value="stripe" class="custom-control-input">
            <label class="custom-control-label" for="stripe">Stripe</label>

            <input type="hidden" id="isStripeSandboxEnabled">
            <input type="hidden" id="stripeKey">
            <input type="hidden" id="stripeSecret">
        </div>

        <div class="custom-control custom-radio border-bottom py-2" style="display:none;" id="paypal_box">
            <input type="radio" name="payment_method" id="paypal"  value="paypal" class="custom-control-input">
            <label class="custom-control-label" for="paypal">Paypal</label>

            <input type="hidden" id="ispaypalSandboxEnabled">
            <input type="hidden" id="paypalKey">
            <input type="hidden" id="paypalSecret">
        </div>

        


    
</div>
    <!-- <div class="siddhi-card bg-white overflow-hidden">
    <div class="siddhi-card-header" id="headingThree">
    <h2 class="mb-0">
    <button class="d-flex p-3 align-items-center btn btn-link w-100" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
    <i class="feather-dollar-sign mr-3"></i> Cash on Delivery
    <i class="feather-chevron-down ml-auto"></i>
    </button>
    </h2>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
    <div class="card-body border-top">
    <h6 class="mb-3 mt-0 mb-3 font-weight-bold">Cash</h6>
    <p class="m-0">Please keep exact change handy to help us serve you better</p>
    </div>
    </div>
    </div> -->
</div>
</div>
</div>
<div class="col-md-4">
<div class="siddhi-cart-item rounded rounded shadow-sm overflow-hidden bg-white sticky_sidebar" id="cart_list">

<?php echo $__env->make('restaurant.cart_item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="modal fade" id="exampleModalAddress" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Delivery Address</h5>
<button type="button" id="close_button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<form class="">
<div class="form-row">
<div class="col-md-12 form-group">
<label class="form-label">Street 1</label>
<div class="input-group">
 <input placeholder="Delivery Area" type="text" id="address_line1" class="form-control">
<div class="input-group-append"><button type="button" class="btn btn-outline-secondary"><i class="feather-map-pin"></i></button></div>
</div>
</div>
<div class="col-md-12 form-group"><label class="form-label">Landmark</label><input placeholder="Complete Address e.g. house number, street name, landmark" value="" id="address_line2" type="text" class="form-control"></div>
<div class="col-md-12 form-group"><label class="form-label">Zip Code</label><input placeholder="Zip Code" id="address_zipcode" type="text" class="form-control"></div>
<div class="col-md-12 form-group"><label class="form-label">City</label><input placeholder="City" id="address_city" type="text" class="form-control"></div>
<div class="col-md-12 form-group"><label class="form-label">Country</label><input placeholder="Country" id="address_country" type="text" class="form-control"></div>
<!-- <div class="mb-0 col-md-12 form-group">
<label class="form-label">Nickname</label>
<div class="btn-group btn-group-toggle w-100" data-toggle="buttons">
<label class="btn btn-outline-secondary active">
<input type="radio" name="options" id="option12" checked> Home
</label>
<label class="btn btn-outline-secondary">
<input type="radio" name="options" id="option22"> Work
</label>
<label class="btn btn-outline-secondary">
<input type="radio" name="options" id="option32"> Other
</label>
</div>
</div>
</div> -->
</form>
</div>
<div class="modal-footer p-0 border-0">
<div class="col-6 m-0 p-0">
<button type="button" class="btn border-top btn-lg btn-block" data-dismiss="modal">Close</button>
</div>
<div class="col-6 m-0 p-0">
<button type="button" class="btn btn-primary btn-lg btn-block" onclick="saveShippingAddress()">Save changes</button>
</div>
</div>
</div>
</div>
</div>
<div class="siddhi-menu-fotter fixed-bottom bg-white px-3 py-2 text-center d-none">
<div class="row">
<div class="col selected">
<a href="home.html" class="text-danger small font-weight-bold text-decoration-none">
<p class="h4 m-0"><i class="feather-home text-danger"></i></p>
Home
</a>
</div>
<div class="col">
<a href="most_popular.html" class="text-dark small font-weight-bold text-decoration-none">
<p class="h4 m-0"><i class="feather-map-pin"></i></p>
Trending
</a>
</div>
<div class="col bg-white rounded-circle mt-n4 px-3 py-2">
<div class="bg-danger rounded-circle mt-n0 shadow">
<a href="checkout.html" class="text-white small font-weight-bold text-decoration-none">
<i class="feather-shopping-cart"></i>
</a>
</div>
</div>
<div class="col">
<a href="favorites.html" class="text-dark small font-weight-bold text-decoration-none">
<p class="h4 m-0"><i class="feather-heart"></i></p>
Favorites
</a>
</div>
<div class="col">
<a href="profile.html" class="text-dark small font-weight-bold text-decoration-none">
<p class="h4 m-0"><i class="feather-user"></i></p>
Profile
</a>
</div>
</div>
</div>


<script src="https://unpkg.com/geofirestore/dist/geofirestore.js"></script>
<script type="text/javascript">
    
    var id_order = "<?php echo uniqid();?>";
    var userId =  "<?php echo $id; ?>";
    var userDetailsRef= database.collection('users').where('id',"==",userId);
    var vendorDetailsRef= database.collection('vendors');
    var AdminCommission = database.collection('settings').doc('AdminCommission');
    var razorpaySettings = database.collection('settings').doc('razorpaySettings');
    var stripeSettings = database.collection('settings').doc('stripeSettings');
    var paypalSettings = database.collection('settings').doc('paypalSettings');
    //shippingAddress
    /*var vendorId =  "";
    
    var vendorDetailsRef= database.collection('vendors').where('id',"==",vendorId);
    var vendorProductsRef = database.collection('vendor_products').where('vendorID',"==",vendorId);
    var vendorRatings = database.collection('foods_review').where('VendorId',"==",vendorId);*/
    var geoFirestore = new GeoFirestore(firestore);

    $( document ).ready(function() {

        getUserDetails();
            
        $(document).on("click", '.remove_item', function(event) { 
            var id=$(this).attr('data-id');
            var restaurant_id=$(this).attr('data-restaurant');
            $.ajax({
               type:'POST',
               url:"<?php echo route('remove-from-cart'); ?>",
               data:{_token:'<?php echo csrf_token() ?>',restaurant_id:restaurant_id,id:id,is_checkout:1},
               success:function(data) {
                   data=JSON.parse(data);
                   $('#cart_list').html(data.html);
               }
            });

        });

        $(document).on("click", '.count-number-input-cart', function(event) { 
            var id=$(this).attr('data-id');
            var restaurant_id=$(this).attr('data-restaurant');
            var quantity=$('.count_number_'+id).val();
            console.log(quantity);
            $.ajax({
               type:'POST',
               url:"<?php echo route('change-quantity-cart'); ?>",
               data:{_token:'<?php echo csrf_token() ?>',restaurant_id:restaurant_id,id:id,quantity:quantity,is_checkout:1},
               success:function(data) {
                   data=JSON.parse(data);
                   $('#cart_list').html(data.html);
               }
            });

        });

        $(document).on("click", '#apply-coupon-code', function(event) { 
            var coupon_code=$("#coupon_code").val();
            var restaurant_id=$(this).attr('data-restaurant');
            var couponCodeRef = database.collection('coupons').where('code',"==",coupon_code);
            couponCodeRef.get().then( async function(couponSnapshots){
                if(couponSnapshots.docs && couponSnapshots.docs.length){
                    var coupondata=couponSnapshots.docs[0].data();  
                    if(coupondata.vendorID!=undefined){
                        if(coupondata.vendorID==restaurant_id){
                            discount=coupondata.discount;
                            discountType=coupondata.discountType;   
                            $.ajax({
                               type:'POST',
                               url:"<?php echo route('apply-coupon'); ?>",
                               data:{_token:'<?php echo csrf_token() ?>',coupon_code:coupon_code,discount:discount,discountType:discountType,is_checkout:1},
                               success:function(data) {
                                   data=JSON.parse(data);
                                   $('#cart_list').html(data.html);
                               }
                            }); 

                        }else{
                            alert("Coupon code is not valid.");
                            $("#coupon_code").val('');
                        }
                    }else{
                        discount=coupondata.discount;
                        discountType=coupondata.discountType;   
                        $.ajax({
                           type:'POST',
                           url:"<?php echo route('apply-coupon'); ?>",
                           data:{_token:'<?php echo csrf_token() ?>',coupon_code:coupon_code,discount:discount,discountType:discountType,is_checkout:1},
                           success:function(data) {
                               data=JSON.parse(data);
                               $('#cart_list').html(data.html);
                           }
                        });
                    }
                }else{
                    alert("Coupon code is not valid.");
                    $("#coupon_code").val('');
                }
                
                

            });
            

        });

    });

    async function getUserDetails(){

        AdminCommission.get().then( async function(AdminCommissionSnapshots){
            AdminCommission=AdminCommissionSnapshots.data();
            if(AdminCommission.isEnabled){
                AdminCommission=AdminCommission.fix_commission;
                $("#adminCommission").val(AdminCommission);
            }else{
                $("#adminCommission").val(0);
            }
        });

        razorpaySettings.get().then( async function(razorpaySettingsSnapshots){
            razorpaySetting=razorpaySettingsSnapshots.data();
            if(razorpaySetting.isEnabled){
                var isEnabled=razorpaySetting.isEnabled;
                $("#isEnabled").val(isEnabled);
                var isSandboxEnabled=razorpaySetting.isSandboxEnabled;
                $("#isSandboxEnabled").val(isSandboxEnabled);
                var razorpayKey=razorpaySetting.razorpayKey;
                $("#razorpayKey").val(razorpayKey);
                var razorpaySecret=razorpaySetting.razorpaySecret;
                $("#razorpaySecret").val(razorpaySecret);
                $("#razorpay_box").show();

            }
        });

        stripeSettings.get().then( async function(stripeSettingsSnapshots){
            stripeSetting=stripeSettingsSnapshots.data();
            if(stripeSetting.isEnabled){
                var isEnabled=stripeSetting.isEnabled;
                var isSandboxEnabled=stripeSetting.isSandboxEnabled;
                $("#isStripeSandboxEnabled").val(isSandboxEnabled);
                var stripeKey=stripeSetting.stripeKey;
                $("#stripeKey").val(stripeKey);
                var stripeSecret=stripeSetting.stripeSecret;
                $("#stripeSecret").val(stripeSecret);
                $("#stripe_box").show();

            }
        });

        paypalSettings.get().then( async function(paypalSettingsSnapshots){
            paypalSetting=paypalSettingsSnapshots.data();
            if(paypalSetting.isEnabled){
                var isEnabled=paypalSetting.isEnabled;
                var isLive=paypalSetting.isLive;
                if(isLive){
                    $("#ispaypalSandboxEnabled").val(false);
                }else{
                    $("#ispaypalSandboxEnabled").val(true);
                }
                var paypalAppId=paypalSetting.paypalAppId;
                $("#paypalKey").val(paypalAppId);
                var paypalSecret=paypalSetting.paypalSecret;
                $("#paypalSecret").val(paypalSecret);
                $("#paypal_box").show();

            }
        });
        


        userDetailsRef.get().then( async function(userSnapshots){
            var userDetails = userSnapshots.docs[0].data();
            var full_address='';

            if(userDetails.shippingAddress!=undefined){

                if(userDetails.shippingAddress.line1!=undefined){
                    $("#line_1").html(userDetails.shippingAddress.line1);
                    $("#address_line1").val(userDetails.shippingAddress.line1);
                }
                if(userDetails.shippingAddress.line2!=undefined){
                    $("#address_line2").val(userDetails.shippingAddress.line2);
                    if(full_address!=''){
                        full_address=full_address+','+userDetails.shippingAddress.line2;
                    }else{
                        full_address=userDetails.shippingAddress.line2;
                    }
                }

                if(userDetails.shippingAddress.city!=undefined){
                    $("#address_city").val(userDetails.shippingAddress.city);
                    if(full_address!=''){
                        full_address=full_address+','+userDetails.shippingAddress.city;
                    }else{
                        full_address=userDetails.shippingAddress.city;
                    }
                }

                if(userDetails.shippingAddress.postalCode!=undefined){
                    $("#address_zipcode").val(userDetails.shippingAddress.postalCode);
                    if(full_address!=''){
                        full_address=full_address+','+userDetails.shippingAddress.postalCode;
                    }else{
                        full_address=userDetails.shippingAddress.postalCode;
                    }
                }

                if(userDetails.shippingAddress.country!=undefined){
                    $("#address_country").val(userDetails.shippingAddress.country);
                    if(full_address!=''){
                        full_address=full_address+','+userDetails.shippingAddress.country;
                    }else{
                        full_address=userDetails.shippingAddress.country;
                    }
                }

                $("#line_2").html(full_address);

                $("#add_address").hide();
                $("#address_box").show();
            }else{
                $("#address_box").hide();
                $("#add_address").show();
            }
            
        });
    }

    function saveShippingAddress() {
        
        userDetailsRef.get().then( async function(userSnapshots){
            var userDetails = userSnapshots.docs[0].data();
            var shippingAddress=userDetails.shippingAddress;
            shippingAddress.line1=$("#address_line1").val();
            shippingAddress.line2=$("#address_line2").val();
            shippingAddress.city=$("#address_city").val();
            shippingAddress.country=$("#address_country").val();
            shippingAddress.postalCode=$("#address_zipcode").val();
            
            /*coordinates=new firebase.firestore.GeoPoint(userDetails.location.latitude,userDetails.location.longitude);
            geoFirestore.collection('users').doc(userId).update({'coordinates':coordinates}).then(() => {
                console.log('Provided document has been updated in Firestore');
              }, (error) => {
                console.log('Error: ' + error);
              });*/

            database.collection('users').doc(userId).update({'shippingAddress':shippingAddress}).then(function(result) {
                    $('#close_button').trigger( "click" );
             });
        });
    }

    function finalCheckout() {
        userDetailsRef.get().then( async function(userSnapshots){

            var vendorID=$("#main_restaurant_id").val();
            var userDetails = userSnapshots.docs[0].data();
            
            vendorDetailsRef.where('id',"==",vendorID).get().then( async function(vendorSnapshots){
            var vendorDetails=vendorSnapshots.docs[0].data();
            
            if(vendorDetails){
                var products=[];
                $( ".product-item" ).each(function( index ) {
                    product_id=$(this).attr("data-id");
                    price=$("#price_"+product_id).val();
                    photo=$("#photo_"+product_id).val();
                    total_pay=$("#total_pay").val();
                    extras_price=$("#extras_price_"+product_id).val();
                    size=$("#size_"+product_id).val();
                    name=$("#name_"+product_id).val();
                    quantity=$("#quantity_"+product_id).val();
                    extras=[];
                    $( ".extras_"+product_id ).each(function( index ) {
                        val=$(this).val();
                        if(val){
                            extras.push(val);
                        }
                    })

                    products.push({'id':product_id,'name':name,'photo':photo,'price':price,'quantity':parseInt(quantity),'vendorID':vendorDetails.id,'extras_price':extras_price,'extras':extras,'size':size})
                });
                var address=userDetails.shippingAddress;
                var author=userDetails;
                var authorID=userId;
                var authorName=userDetails.firstName;

                var couponCode=$("#coupon_code_main").val();
                var couponId=$("#coupon_id").val();
                var createdAt= firebase.firestore.FieldValue.serverTimestamp();
                var discount=$("#discount_amount").val();
                var driver=[];
                var vendor=vendorDetails;
                var status='Order Placed';
                var delivery_charge=$("#deliveryCharge").val();
                var tip_amount=$("#tip_amount").val();
                var adminCommission=$("#adminCommission").val();

                var payment_method=$('input[name="payment_method"]:checked').val();
                var delivery_option=$('input[name="delivery_option"]').val();
                var take_away=false;
                if(delivery_option=="takeaway"){
                    take_away=true;
                }

                if(payment_method=="razorpay"){
                    var razorpayKey=$("#razorpayKey").val();
                    var razorpaySecret=$("#razorpaySecret").val();
                    var order_json={authorID:authorID,couponCode:couponCode,couponId:couponId,id:id_order,products:products,status:status,vendorID:vendorDetails.id,delivery_charge:delivery_charge,tip_amount:tip_amount,adminCommission:adminCommission,take_away:take_away};
                    $.ajax({
                           type:'POST',
                           url:"<?php echo route('order-proccessing'); ?>",
                           data:{_token:'<?php echo csrf_token() ?>',order_json:order_json,razorpaySecret:razorpaySecret,razorpayKey:razorpayKey,payment_method:payment_method,authorName:authorName,total_pay:total_pay},
                           success:function(data) {
                               data=JSON.parse(data);
                               $('#cart_list').html(data.html);
                               window.location.href = "<?php echo route('pay'); ?>";
                               
                           }
                    }); 
                               

                }if(payment_method=="stripe"){
                    var stripeKey=$("#stripeKey").val();
                    var stripeSecret=$("#stripeSecret").val();
                    var isStripeSandboxEnabled=$("#isStripeSandboxEnabled").val();
                    var order_json={authorID:authorID,couponCode:couponCode,couponId:couponId,id:id_order,products:products,status:status,vendorID:vendorDetails.id,delivery_charge:delivery_charge,tip_amount:tip_amount,adminCommission:adminCommission,take_away:take_away};
                    $.ajax({
                           type:'POST',
                           url:"<?php echo route('order-proccessing'); ?>",
                           data:{_token:'<?php echo csrf_token() ?>',order_json:order_json,stripeKey:stripeKey,stripeSecret:stripeSecret,payment_method:payment_method,authorName:authorName,total_pay:total_pay,isStripeSandboxEnabled:isStripeSandboxEnabled,address_line1:$("#address_line1").val(),address_line2:$("#address_line2").val(),address_zipcode:$("#address_zipcode").val(),address_city:$("#address_city").val(),address_country:$("#address_country").val()},
                           success:function(data) {
                               data=JSON.parse(data);
                               $('#cart_list').html(data.html);
                               window.location.href = "<?php echo route('pay'); ?>";
                               
                           }
                    }); 
                               

                }else if(payment_method=="paypal"){

                    var paypalKey=$("#paypalKey").val();
                    var paypalSecret=$("#paypalSecret").val();
                    var ispaypalSandboxEnabled=$("#ispaypalSandboxEnabled").val();
                    var order_json={authorID:authorID,couponCode:couponCode,couponId:couponId,id:id_order,products:products,status:status,vendorID:vendorDetails.id,delivery_charge:delivery_charge,tip_amount:tip_amount,adminCommission:adminCommission,take_away:take_away};
                    $.ajax({
                           type:'POST',
                           url:"<?php echo route('order-proccessing'); ?>",
                           data:{_token:'<?php echo csrf_token() ?>',order_json:order_json,paypalKey:paypalKey,paypalSecret:paypalSecret,payment_method:payment_method,authorName:authorName,total_pay:total_pay,ispaypalSandboxEnabled:ispaypalSandboxEnabled,address_line1:$("#address_line1").val(),address_line2:$("#address_line2").val(),address_zipcode:$("#address_zipcode").val(),address_city:$("#address_city").val(),address_country:$("#address_country").val()},
                           success:function(data) {
                               data=JSON.parse(data);
                               $('#cart_list').html(data.html);
                               window.location.href = "<?php echo route('pay'); ?>";
                               
                           }
                    }); 

                }else{

                    database.collection('restaurant_orders').doc(id_order).set({'address':address,'author':author,'authorID':authorID,'couponCode':couponCode,'couponId':couponId,"createdAt":createdAt,'id':id_order,'products':products,'status':status,'vendor':vendorDetails,'vendorID':vendorDetails.id,'delivery_charge':delivery_charge,'tip_amount':tip_amount,'adminCommission':adminCommission,'payment_method':'cod','takeAway':take_away}).then(function(result) {
                         
                         $.ajax({
                           type:'POST',
                           url:"<?php echo route('order-complete'); ?>",
                           data:{_token:'<?php echo csrf_token() ?>'},
                           success:function(data) {
                               data=JSON.parse(data);
                               $('#cart_list').html(data.html);
                               window.location.href = "<?php echo url(''); ?>";
                               
                           }
                        }); 

                    });

                }   
            
            }
            
            }); 
        });
    }
    //tip_amount
    $(document).on("click", '#Other_tip', function(event) { 
        $("#add_tip_box").show();
    });
    $(document).on("click", '.this_tip', function(event) {
        var this_tip=$(this).val();
        $("#tip_amount").val(this_tip);
        $("#add_tip_box").hide();
        tipAmountChange();
    });

    $(document).on("onchange", '#tip_amount', function(event) {
            tipAmountChange();
    });

    function tipAmountChange() {
        
         var this_tip=$("#tip_amount").val();
        $.ajax({
               type:'POST',
               url:"<?php echo route('order-tip-add'); ?>",
               data:{_token:'<?php echo csrf_token() ?>',is_checkout:1,tip:this_tip},
               success:function(data) {
                   data=JSON.parse(data);
                   $('#cart_list').html(data.html);
               }
        }); 

    }


</script><?php /**PATH /home/foodie/public_html/website/resources/views/checkout/checkout.blade.php ENDPATH**/ ?>