<footer class="section-footer border-top bg-dark">
<div class="container">
<section class="footer-top padding-y py-5">
<div class="row">
<aside class="col-md-6 footer-about">
<article class="d-flex pb-3">
<div><img alt="#" src="<?php echo e(asset('img/logo_web.png')); ?>" class="logo-footer mr-3"></div>
<div>
<h6 class="title text-white">About Us</h6>
<p class="text-muted">Some short text about company like You might remember the Dell computer commercials in which a youth reports.</p>
<div class="d-flex align-items-center">
<a class="btn btn-icon btn-outline-light mr-1 btn-sm" title="Facebook" target="_blank" href="#"><i class="feather-facebook"></i></a>
<a class="btn btn-icon btn-outline-light mr-1 btn-sm" title="Instagram" target="_blank" href="#"><i class="feather-instagram"></i></a>
<a class="btn btn-icon btn-outline-light mr-1 btn-sm" title="Youtube" target="_blank" href="#"><i class="feather-youtube"></i></a>
<a class="btn btn-icon btn-outline-light mr-1 btn-sm" title="Twitter" target="_blank" href="#"><i class="feather-twitter"></i></a>
</div>
</div>
</article>
</aside>
<!-- <aside class="col-sm-3 col-md-2 text-white">
<h6 class="title">Error Pages</h6>
<ul class="list-unstyled hov_footer">
<li> <a href="<?php echo e(url('/not_found')); ?>" class="text-muted">Not found</a></li>
<li> <a href="<?php echo e(url('/maintence')); ?>" class="text-muted">Maintence</a></li>
<li> <a href="<?php echo e(url('/coming_soon')); ?>" class="text-muted">Coming Soon</a></li>
</ul>
</aside> -->
<aside class="col-sm-4 col-md-2 text-white">
<h6 class="title">Services</h6>
<ul class="list-unstyled hov_footer">
<li> <a href="#" class="text-muted">Delivery Support</a></li>
<li> <a href="<?php echo e(url('contact_us')); ?>" class="text-muted">Contact Us</a></li>
<li> <a href="#" class="text-muted">Terms of use</a></li>
<li> <a href="#" class="text-muted">Privacy policy</a></li>
</ul>
</aside>
<aside class="col-sm-4  col-md-2 text-white">
<h6 class="title">For users</h6>
<ul class="list-unstyled hov_footer">
<li> <a href="<?php echo e(url('login')); ?>" class="text-muted"> User Login </a></li>
<li> <a href="<?php echo e(url('signup')); ?>" class="text-muted"> User register </a></li>
<li> <a href="#" class="text-muted"> Forgot Password </a></li>
<li> <a href="#" class="text-muted"> Account Setting </a></li>
</ul>
</aside>
<aside class="col-sm-4  col-md-2 text-white">
<h6 class="title">Quik Links</h6>
<ul class="list-unstyled hov_footer">
<li> <a href="#" class="text-muted"> Trending </a></li>
<li> <a href="#" class="text-muted"> Most popular </a></li>
<li> <a href="#" class="text-muted"> Restaurant Details </a></li>
<li> <a href="#" class="text-muted"> Favorites </a></li>
</ul>
</aside>
</div>

</section>


</div>

<section class="footer-copyright border-top py-3 bg-light">
<div class="container d-flex align-items-center">
<p class="mb-0"> © 2022 Company All rights reserved </p>
<p class="text-muted mb-0 ml-auto d-flex align-items-center">
<a href="#" class="d-block"><img alt="#" src="<?php echo e(asset('img/appstore.png')); ?>" height="40"></a>
<a href="#" class="d-block ml-3"><img alt="#" src="<?php echo e(asset('img/playmarket.png')); ?>" height="40"></a>
</p>
</div>
</section>
</footer>

<script type="text/javascript" src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendor/sidebar/hc-offcanvas-nav.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendor/slick/slick.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/siddhi.js')); ?>"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-storage.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-database.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/crypto-js.js"></script>
<!-- <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&libraries=places"></script> -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAtJPpofwoyhKCbrX_FBigtZ5bsN6qs89k&libraries=places&v=3.43"></script> -->

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAT07iMlfZ9bJt1gmGj9KhJDLFY8srI6dA&libraries=places&callback=initialize"></script>

<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyALXmmuvA_RcrerFRcmUxdIoiqPl2cECy8&libraries=places"></script> -->

<script type="text/javascript">
    function initialize() {
      var input = document.getElementById('user_locationnew');
      new google.maps.places.Autocomplete(input);
    }

    google.maps.event.addDomListener(window, 'load', initialize);
</script>
<script type="text/javascript"><?php echo $__env->make('vendor.init_firebase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></script>

<script type="text/javascript">
    

<?php 

	use App\Models\user;
	use App\Models\VendorUsers;

	$user_email = '';
	$user_uuid = '';
	$auth_id = Auth::id();
	if($auth_id){
		$user = user::select('email')->where('id',$auth_id)->first();	
		$user_email = $user->email;
		$user_uuid = VendorUsers::select('user_id')->where('email',$user_email)->first();	
		$user_uuid = $user_uuid->user_id;

	}
	 ?>
	 	var database = firebase.firestore();
	 	var placeholderImageHeader = '';
	 	var googleMapKeySettingHeader = database.collection('settings').doc("googleMapKey");
	 	googleMapKeySettingHeader.get().then( async function(googleMapKeySnapshotsHeader){
    		var placeholderImageHeaderData = googleMapKeySnapshotsHeader.data();
    		placeholderImageHeader = placeholderImageHeaderData.placeHolderImage;
  		})
	var user_email = "<?php echo $user_email;  ?>";
	var user_ref = '';
	 if(user_email != ''){
	 	var user_uuid ="<?php echo $user_uuid; ?>";
	 	user_ref = database.collection('users').where("email","==",user_email);
	 }

	$(document).ready(function(){
	  jQuery("#data-table_processing").show();
	  if(user_ref != ''){
	  user_ref.get().then( async function(profileSnapshots){
		var profile_user = profileSnapshots.docs[0].data();
		var profile_name = profile_user.firstName+" "+profile_user.lastName;
	  	if(profile_user.profilePictureURL != ''){
	   	    $("#dropdownMenuButton").append('<img alt="#" src="'+profile_user.profilePictureURL+'" class="img-fluid rounded-circle header-user mr-2 header-user">Hi '+profile_user.firstName);
	    }else{
	    	 $("#dropdownMenuButton").append('<img alt="#" src="'+placeholderImageHeader+'" class="img-fluid rounded-circle header-user mr-2 header-user">Hi '+profile_user.firstName);
	    }
	    $("#user_location").html(profile_user.shippingAddress.city);
		})
	}
  })


	$(".user-logout-btn").click( async function() {
		firebase.auth().signOut().then(function(){
			var logoutURL = "<?php echo e(route('logout')); ?>";
			console.log(logoutURL);
			$.ajax({
          		type:'POST',
          		url:logoutURL,
          		data:{},
          		headers: {
        			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    					},
          		success:function(data1){
          			if(data1.logoutuser){
                          window.location = "<?php echo e(route('login')); ?>";		
                    }
          		}
          	})
				
		});
    });
</script>
 
<script type="text/javascript" src="<?php echo e(asset('js/rocket-loader.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('https://static.cloudflareinsights.com/beacon.min.js')); ?>"></script>
<?php /**PATH /home/foodie/public_html/website/resources/views/layouts/footer.blade.php ENDPATH**/ ?>