<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<header class="section-header">
	<?php
	if(Session::get('takeawayOption')=='true' || Session::get('takeawayOption')==true){
		$takeaway_options=true;
	}else{
		$takeaway_options=false;
	}
	?>
	<script>
	<?php if($takeaway_options){ ?>
	var takeaway_options=true;
	<?php }else{ ?>
	var takeaway_options=false;
	<?php } ?>
	function takeAwayOnOff(takeAway){
	var check_val;
	if(takeaway_options==true){
	if (takeAway.checked == false ) {
	
	let isExecuted = confirm("If you select take away option then it will empty cart. are you sure want to do ?");
	if(isExecuted){
	}else{
	return false;
	}
	}
	}
	if (takeAway.checked == true ) {
	check_val = true;
	takeaway_options= true;
	}else{
	check_val = false;
	takeaway_options= false;
	}
	
	$.ajax({
	data: {
	takeawayOption: check_val,
	"_token": "<?php echo e(csrf_token()); ?>",
	},
	url: 'takeaway',
	type: 'POST',
	success: function(result){ result=$.parseJSON(result);  console.log(result.data);  location.reload();  }});
	}
	</script>
	<section class="header-main shadow-sm bg-white">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-2">
					<a href="<?php echo e(url('/')); ?>" class="brand-wrap mb-0">
						<img alt="#" class="img-fluid" src="<?php echo e(asset('img/logo_web.png')); ?>" id="logo_web">
					</a>
				</div>
				<div class="col-3 d-flex align-items-center m-none head-search">
					<div class="dropdown mr-3">
						<a class="text-dark dropdown-toggle d-flex align-items-center py-3" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<div class="head-loc" onclick="getCurrentLocation('reload')"><i class="feather-map-pin mr-2 bg-light rounded-pill p-2 icofont-size"></i></div>
							<div>
								<!-- <p class="text-muted mb-0 small">Select Location</p> -->
								<!-- <div id="user_location"></div> -->
								<input id="user_locationnew" type="text" size="50" class="pac-target-input">
							</div>
						</a>
					</div>
				</div>
				<div class="col-7 header-right">
					<div class="d-flex align-items-center justify-content-end pr-5">
						<a href="<?php echo e(url('search')); ?>" class="widget-header mr-4 text-dark">
							<div class="icon d-flex align-items-center">
								<i class="feather-search h6 mr-2 mb-0"></i> <span><?php echo e(trans('lang.search')); ?></span>
							</div>
						</a>
						<a href="<?php echo e(url('offers')); ?>" class="widget-header mr-4 text-dark offer-link">
							<div class="icon d-flex align-items-center">
								<!-- <i class="feather-disc h6 mr-2 mb-0"></i> --><img alt="#" class="img-fluid mr-2" src="<?php echo e(asset('img/discount.png')); ?>"> <span><?php echo e(trans('lang.offers')); ?></span>
							</div>
						</a>
						<?php if(auth()->guard()->check()): ?>

						<?php else: ?>

						<a href="<?php echo e(url('login')); ?>" class="widget-header mr-4 text-dark m-none">
							<div class="icon d-flex align-items-center">
								<i class="feather-user h6 mr-2 mb-0"></i> <span><?php echo e(trans('lang.signin')); ?></span>
							</div>
						</a>
						<?php endif; ?>
						<div class="dropdown mr-4 m-none">
							<a href="#" class="dropdown-toggle text-dark py-3 d-block" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

							</a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
								<?php if(auth()->guard()->check()): ?>

								  	<a class="dropdown-item" href="<?php echo e(url('profile')); ?>"><?php echo e(trans('lang.my_account')); ?></a>
								  	<a class="dropdown-item" href="<?php echo e(url('restaurants')); ?>"><?php echo e(trans('lang.all_restaurants')); ?></a>
								  	<a class="dropdown-item dine_in_menu" style="display: none;" href="<?php echo e(url('restaurants')); ?>?dinein=1"><?php echo e(trans('lang.dine_in_restaurants')); ?></a>
									<a class="dropdown-item" href="<?php echo e(route('faq')); ?>"><?php echo e(trans('lang.delivery_support')); ?></a>
									<a class="dropdown-item" href="<?php echo e(url('contact_us')); ?>"><?php echo e(trans('lang.contact_us')); ?></a>
									<a class="dropdown-item" href="<?php echo e(route('terms')); ?>"><?php echo e(trans('lang.terms_use')); ?></a>
									<a class="dropdown-item" href="<?php echo e(route('privacy')); ?>"><?php echo e(trans('lang.privacy_policy')); ?></a>
									<!-- <a class="dropdown-item user-logout-btn" href="#" onclick="event.preventDefault(); ;">Logout</a> -->
									<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();"><?php echo e(trans('lang.logout')); ?></a>

								<?php else: ?>
									<a class="dropdown-item" href="<?php echo e(url('restaurants')); ?>"><?php echo e(trans('lang.all_restaurants')); ?></a>
									<a class="dropdown-item dine_in_menu" style="display: none;" href="<?php echo e(url('restaurants')); ?>?dinein=1"><?php echo e(trans('lang.dine_in_restaurants')); ?></a>
									<a class="dropdown-item" href="<?php echo e(route('faq')); ?>"><?php echo e(trans('lang.delivery_support')); ?></a>
									<a class="dropdown-item" href="<?php echo e(url('contact_us')); ?>"><?php echo e(trans('lang.contact_us')); ?></a>
									<a class="dropdown-item" href="<?php echo e(route('terms')); ?>"><?php echo e(trans('lang.terms_use')); ?></a>
									<a class="dropdown-item" href="<?php echo e(route('privacy')); ?>"><?php echo e(trans('lang.privacy_policy')); ?></a>

								<?php endif; ?>

								
							</div>
						</div>
						<a href="<?php echo e(url('/checkout')); ?>" class="widget-header mr-4 text-dark">
							<div class="icon d-flex align-items-center">
								<i class="feather-shopping-cart h6 mr-2 mb-0"></i> <span><?php echo e(trans('lang.cart')); ?></span>
							</div>
						</a>
						<div class="icon d-flex align-items-center text-dark takeaway-div">
							<span class="takeaway-btn">
								<i class="fa fa-car h6 mr-1 mb-0"></i> <span> <?php echo e(trans('lang.take_away')); ?>  </span>
								<input type="checkbox" onclick="takeAwayOnOff(this)" <?php if(Session::get('takeawayOption')=="true"){ ?> checked <?php } ?>> <span class="slider round"></span>
							</span>
						</div>
						<div style="visibility: hidden;" class="language-list icon d-flex align-items-center text-dark ml-2" id="language_dropdown_box">
				            <div class="language-select">
				                <i class="feather-globe"></i>
				            </div>
				            <div class="language-options">
				                <select class="form-control changeLang text-dark" id="language_dropdown">
				                </select>
				            </div>
				        </div>
						<a class="toggle" href="#">
							<span></span>
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>
</header>
<div class="d-none">
	<div class="bg-primary p-3 d-flex align-items-center">
		<a class="toggle togglew toggle-2" href="#"><span></span></a>
		<!-- <h4 class="font-weight-bold m-0 text-white">Foodie</h4> -->
		<a href="<?php echo e(url('/')); ?>" class="mobile-logo brand-wrap mb-0">
			<img alt="#" class="img-fluid" src="<?php echo e(asset('img/logo_web.png')); ?>">
		</a>
	</div>
</div>
<?php /**PATH H:\Development\wamp\www\foodie\version3.2.2\foodie_website\resources\views/layouts/header.blade.php ENDPATH**/ ?>