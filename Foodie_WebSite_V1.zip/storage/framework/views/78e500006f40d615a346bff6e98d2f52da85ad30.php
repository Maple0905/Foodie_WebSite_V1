


<div class="login-page vh-100">

<div class="d-flex align-items-center justify-content-center vh-100">
<div class="col-md-6">
<div class="col-10 mx-auto card p-3">
<h3 class="text-dark my-0 mb-3">Login</h3>
<p class="text-50">Sign in to continue</p>
<form class="mt-3 mb-4" action="#" onsubmit="return loginClick()">
<div class="form-group">
<label for="email" class="text-dark">Email</label>
<input type="email" placeholder="Enter Email" class="form-control" id="email" aria-describedby="emailHelp" name="email">
 <div id="emil_required"></div>
</div>



<div class="form-group">
<label for="password" class="text-dark">Password</label>
<input type="password" placeholder="Enter Password" class="form-control" id="password" name="password">
<div class="error" id="password_required"></div>

</div>
<button type="submit" class="btn btn-primary btn-lg btn-block" id="login_btn">SIGN IN</button>
<!-- <div class="py-2">
<button class="btn btn-lg btn-facebook btn-block"><i class="feather-facebook"></i> Connect with Facebook</button>
</div> -->
</form>

</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>








<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-firestore.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-storage.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase-database.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/crypto-js.js"></script>

<script type="text/javascript"><?php echo $__env->make('vendor.init_firebase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></script>

<script type="text/javascript">
		 var database = firebase.firestore();
  //$(".login_btn").click(async function(){
          function loginClick(){
        	var email = $("#email").val();
        	var password = $("#password").val(); 

        	firebase.auth().signInWithEmailAndPassword(email, password).then(function(result) {
          			var userEmail = result.user.email;
          			database.collection("users").where("email","==",userEmail).get().then( async function(snapshots){
          				var userData = snapshots.docs[0].data();
          				if(userData.role == "customer"){
          					var userToken = result.user.getIdToken();
          					var uid = result.user.uid;
                    		var user = userData.id;
                    		var firstName = userData.firstName;
                    		var lastName = userData.lastName;
                    		var imageURL = userData.profilePictureURL;
          					    var url = "<?php echo e(route('setToken')); ?>";
          					$.ajax({
          						type:'POST',
          						url:url,
          						data:{id:uid,userId:user,email:email,password:password,firstName:firstName,lastName:lastName,profilePicture:imageURL},
          					   	headers: {
        							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    									},
          						success:function(data){
          						  if(data.access){
                          				
                          				window.location = "<?php echo e(route('contact_us')); ?>";
                        		  }
          						}
          					})
          					
          				}else{

          				}
          			})

        	})
        .catch(function(error) {
          		console.log(error.message);
          		$("#password_required").html(error.message);
        	});
        return false;
    	}

</script>
<?php echo $__env->make('auth.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/foodie/public_html/website/resources/views/auth/loginuser.blade.php ENDPATH**/ ?>