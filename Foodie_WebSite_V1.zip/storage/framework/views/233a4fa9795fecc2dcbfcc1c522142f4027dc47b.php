<p>Hi, This is <?php echo e($data['name']); ?></p>
<p>I have some query like <?php echo e($data['message']); ?>.</p>
<p>It would be appriciative, if you gone through this feedback.</p><?php /**PATH /home/customer/www/foodieweb.siswebapp.com/resources/views/contact_us/send_email.blade.php ENDPATH**/ ?>