
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-none">
<div class="bg-primary border-bottom p-3 d-flex align-items-center">
<a class="toggle togglew toggle-2" href="#"><span></span></a>
<h4 class="font-weight-bold m-0 text-white">My Order</h4>
</div>
</div>
<section class="py-4 siddhi-main-body">
<div class="container">
<div class="row">
<div class="col-md-3 mb-3">
<ul class="nav nav-tabsa custom-tabsa border-0 flex-column bg-white rounded overflow-hidden shadow-sm p-2 c-t-order" id="myTab" role="tablist">
<li class="nav-item" role="presentation">
<a class="nav-link border-0 text-dark py-3 active" id="completed-tab" data-toggle="tab" href="#completed" role="tab" aria-controls="completed" aria-selected="true">
<i class="feather-check mr-2 text-success mb-0"></i> Completed</a>
</li>
<li class="nav-item border-top" role="presentation">
<a class="nav-link border-0 text-dark py-3" id="progress-tab" data-toggle="tab" href="#progress" role="tab" aria-controls="progress" aria-selected="false">
<i class="feather-clock mr-2 text-warning mb-0"></i> On Progress</a>
</li>
<li class="nav-item border-top" role="presentation">
<a class="nav-link border-0 text-dark py-3" id="canceled-tab" data-toggle="tab" href="#canceled" role="tab" aria-controls="canceled" aria-selected="false">
<i class="feather-x-circle mr-2 text-danger mb-0"></i> Canceled</a>
</li>
</ul>
</div>
<div class="tab-content col-md-9" id="myTabContent">
<div class="tab-pane fade show active" id="completed" role="tabpanel" aria-labelledby="completed-tab">
<div class="order-body">
	<div id="completed_orders"></div>
<!-- <div class="pb-3">
<div class="p-3 rounded shadow-sm bg-white">
<div class="d-flex border-bottom pb-3">
<div class="text-muted mr-3">
<img alt="#" src="<?php echo e(asset('img/popular5.png')); ?>" class="img-fluid order_img rounded">
 </div>
<div>
<p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
<p class="mb-0">Punjab, India</p>
<p>ORDER #321DERS</p>
<p class="mb-0 small"><a href="status_complete.html">View Details</a></p>
</div>
<div class="ml-auto">
<p class="bg-success text-white py-1 px-2 rounded small mb-1">Delivered</p>
<p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
</div>
</div>
<div class="d-flex pt-3">
<div class="small">
<p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
<p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
</div>
<div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
<span class="text-dark font-weight-bold">$12.74</span>
</div>
<div class="text-right">
<a href="checkout.html" class="btn btn-primary px-3">Reorder</a>
<a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
</div>
</div>
</div>
</div>
<div class="pb-3">

<div class="p-3 rounded shadow-sm bg-white">
<div class="d-flex border-bottom pb-3">
<div class="text-muted mr-3">
<img alt="#" src="<?php echo e(asset('img/popular4.png')); ?>" class="img-fluid order_img rounded">
</div>
<div>
<p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
<p class="mb-0">Punjab, India</p>
<p>ORDER #321DERS</p>
<p class="mb-0 small"><a href="status_complete.html">View Details</a></p>
</div>
<div class="ml-auto">
<p class="bg-success text-white py-1 px-2 rounded small mb-1">Delivered</p>
<p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
</div>
</div>
<div class="d-flex pt-3">
<div class="small">
<p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
<p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
</div>
<div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
<span class="text-dark font-weight-bold">$12.74</span>
</div>
 <div class="text-right">
<a href="checkout.html" class="btn btn-primary px-3">Reorder</a>
<a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
</div>
</div>
</div> 
</div> -->
</div>
</div> 
<div class="tab-pane fade" id="progress" role="tabpanel" aria-labelledby="progress-tab">
<div class="order-body">
	<div id="pending_orders"></div>
<!-- <div class="pb-3">
<div class="p-3 rounded shadow-sm bg-white">
<div class="d-flex border-bottom pb-3">
<div class="text-muted mr-3">
<img alt="#" src="<?php echo e(asset('img/popular1.png')); ?>" class="img-fluid order_img rounded">
</div>
<div>
<p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
<p class="mb-0">Punjab, India</p>
<p>ORDER #321DERS</p>
<p class="mb-0 small"><a href="status_onprocess.html">View Details</a></p>
</div>
<div class="ml-auto">
<p class="bg-warning text-white py-1 px-2 rounded small mb-1">On Process</p>
<p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
</div>
</div>
<div class="d-flex pt-3">
<div class="small">
<p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
<p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
</div>
<div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
<span class="text-dark font-weight-bold">$12.74</span>
</div>
<div class="text-right">
<a href="status_onprocess.html" class="btn btn-primary px-3">Track</a>
<a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
</div>
</div>
</div>
</div>
<div class="pb-3">
<div class="p-3 rounded shadow-sm bg-white">
<div class="d-flex border-bottom pb-3">
<div class="text-muted mr-3">
<img alt="#" src="<?php echo e(asset('img/popular2.png')); ?>" class="img-fluid order_img rounded">
</div>
<div>
<p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
<p class="mb-0">Punjab, India</p>
<p>ORDER #321DERS</p>
<p class="mb-0 small"><a href="status_onprocess.html">View Details</a></p>
</div>
 <div class="ml-auto">
<p class="bg-warning text-white py-1 px-2 rounded small mb-1">On Process</p>
<p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
</div>
</div>
<div class="d-flex pt-3">
<div class="small">
<p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
<p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
</div>
<div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
<span class="text-dark font-weight-bold">$12.74</span>
</div>
<div class="text-right">
<a href="status_onprocess.html" class="btn btn-primary px-3">Track</a>
<a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
</div>
</div>
</div>
</div>
<div class="pb-3">
<div class="p-3 rounded shadow-sm bg-white">
<div class="d-flex border-bottom pb-3">
<div class="text-muted mr-3">
<img alt="#" src="<?php echo e(asset('img/popular3.png')); ?>" class="img-fluid order_img rounded">
</div>
<div>
<p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
<p class="mb-0">Punjab, India</p>
<p>ORDER #321DERS</p>
<p class="mb-0 small"><a href="status_onprocess.html">View Details</a></p>
</div>
<div class="ml-auto">
<p class="bg-warning text-white py-1 px-2 rounded small mb-1">On Process</p>
<p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
</div>
</div>
<div class="d-flex pt-3">
<div class="small">
<p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
<p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
</div>
<div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
<span class="text-dark font-weight-bold">$12.74</span>
</div>
<div class="text-right">
<a href="status_onprocess.html" class="btn btn-primary px-3">Track</a>
<a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
</div>
</div>
</div>
</div> -->
</div>
</div>
<div class="tab-pane fade" id="canceled" role="tabpanel" aria-labelledby="canceled-tab">
<div class="order-body">
	<div id="rejected_orders"></div>
<!-- <div class="pb-3">
<div class="p-3 rounded shadow-sm bg-white">
<div class="d-flex border-bottom pb-3">
<div class="text-muted mr-3">
<img alt="#" src="<?php echo e(asset('img/popular6.png')); ?>" class="img-fluid order_img rounded">
</div>
<div>
<p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
<p class="mb-0">Punjab, India</p>
<p>ORDER #321DERS</p>
<p class="mb-0 small"><a href="status_canceled.html">View Details</a></p>
</div>
<div class="ml-auto">
<p class="bg-danger text-white py-1 px-2 rounded small mb-1">Payment failed</p>
<p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
</div>
</div>
<div class="d-flex pt-3">
<div class="small">
<p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
<p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
</div>
<div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
<span class="text-dark font-weight-bold">$12.74</span>
</div>
<div class="text-right">
<a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
</div>
</div>
</div>
</div>
<div class="pb-3">
<div class="p-3 rounded shadow-sm bg-white">
<div class="d-flex border-bottom pb-3">
<div class="text-muted mr-3">
<img alt="#" src="<?php echo e(asset('img/popular6.png')); ?>" class="img-fluid order_img rounded">
</div>
<div>
<p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
<p class="mb-0">Punjab, India</p>
<p>ORDER #321DERS</p>
<p class="mb-0 small"><a href="status_canceled.html">View Details</a></p>
</div>
<div class="ml-auto">
<p class="bg-danger text-white py-1 px-2 rounded small mb-1">Canceled</p>
<p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
</div>
</div>
<div class="d-flex pt-3">
<div class="small">
<p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
<p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
</div>
<div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
<span class="text-dark font-weight-bold">$12.74</span>
</div>
<div class="text-right">
<a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
</div>
</div>
</div>
</div> -->
</div>
</div>
</div>
</div>
</div>
</section>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- <script type="8802bf258e6f26bced5d6f62-text/javascript" src="vendor/jquery/jquery.min.js"></script>
<script type="8802bf258e6f26bced5d6f62-text/javascript" src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script type="8802bf258e6f26bced5d6f62-text/javascript" src="vendor/slick/slick.min.js"></script>

<script type="8802bf258e6f26bced5d6f62-text/javascript" src="vendor/sidebar/hc-offcanvas-nav.js"></script>

<script type="8802bf258e6f26bced5d6f62-text/javascript" src="js/siddhi.js"></script>
<script src="js/rocket-loader.min.js" data-cf-settings="8802bf258e6f26bced5d6f62-|49" defer=""></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6c83f3ceed1541ab","version":"2021.12.0","r":1,"token":"dd471ab1978346bbb991feaa79e6ce5c","si":100}' crossorigin="anonymous"></script>
 -->

 <script type="text/javascript">
 	console.log(user_uuid);

    var append_categories = '';
	var completedorsersref= database.collection('restaurant_orders').where("author.id","==",user_uuid);

	$(document).ready(function() {
    	getOrders();
	});

	async function getOrders(){

	    completedorsersref.get().then( async function(completedorderSnapshots){  
		completed_orders = document.getElementById('completed_orders');
		pending_orders = document.getElementById('pending_orders');
		rejected_orders = document.getElementById('rejected_orders');
		
		completed_orders.innerHTML='';
		pending_orders.innerHTML='';
		rejected_orders.innerHTML='';

		completedOrderHtml=buildHTMLCompletedOrders(completedorderSnapshots);
		pendingOrderHtml=buildHTMLPendingOrders(completedorderSnapshots);
		rejectedOrdersHtml=buildHTMLRejectedOrders(completedorderSnapshots);
		
		completed_orders.innerHTML=completedOrderHtml;
		pending_orders.innerHTML=pendingOrderHtml;
		rejected_orders.innerHTML=rejectedOrdersHtml;
	})
	}

	   function buildHTMLCompletedOrders(completedorderSnapshots){
        var html='';
        var alldata=[];
        var number= [];
        completedorderSnapshots.docs.forEach((listval) => {
            var datas=listval.data();
            alldata.push(datas);
        });
                
        alldata.forEach((listval) => {
            console.log(listval.products[0]['name']); 
            var val=listval;

            if(val.status == "Order Completed"){
                var order_id = val.id;
               var view_details = "<?php echo e(route('completed_order',':id')); ?>";
                view_details = view_details.replace(':id', 'id='+order_id);
                                
            html= html+'<div class="pb-3"><div class="p-3 rounded shadow-sm bg-white"><div class="d-flex border-bottom pb-3 m-d-flex"><div class="text-muted mr-3"><img alt="#" src="'+val.vendor.photo+'" class="img-fluid order_img rounded"></div><div><p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">'+val.vendor.title+'</a></p><p class="mb-0">Punjab, India</p><p>ORDER '+val.id+'</p><p class="mb-0 small view-det"><a href="'+view_details+'">View Details</a></p></div><div class="ml-auto ord-com-btn"><p class="bg-success text-white py-1 px-2 rounded small mb-1">'+val.status+'</p><p class="small font-weight-bold text-center"><i class="feather-clock"></i>'+val.createdAt.toDate().toDateString()+'</p></div></div><div class="d-flex pt-3 m-d-flex"><div class="small">';
            var price = 0;
            for(let i = 0; i < val.products.length; i++) {
            	html = html+ '<p class="text- font-weight-bold mb-0">'+val.products[i]['name']+' x '+ val.products[i]['quantity']+'</p>';
            	price = price + val.products[i]['price'] * val.products[i]['quantity'];
            	  }
            html= html+ '<p class="text- font-weight-bold mb-0">'+price+'</p></div><div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br><span class="text-dark font-weight-bold">Total</span></div> <div class="text-right"><a href="checkout.html" class="btn btn-primary px-3">Reorder</a><a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a></div></div></div></div></div></div>';
        }
          });
    
          return html;      
	}

		   function buildHTMLPendingOrders(completedorderSnapshots){
        var html='';
        var alldata=[];
        var number= [];
        completedorderSnapshots.docs.forEach((listval) => {
            var datas=listval.data();
            alldata.push(datas);
        });
                
        alldata.forEach((listval) => {
            console.log(listval.products[0]['name']); 
            var val=listval;
            var order_id = val.id;
            var view_details = "<?php echo e(route('pending_order',':id')); ?>";
            view_details = view_details.replace(':id', 'id='+order_id);

            if(val.status == "Driver Pending" || val.status == "In Transit"){
            html= html+'<div class="pb-3"><div class="p-3 rounded shadow-sm bg-white"><div class="d-flex border-bottom pb-3 m-d-flex"><div class="text-muted mr-3"><img alt="#" src="'+val.vendor.photo+'" class="img-fluid order_img rounded"></div><div><p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">'+val.vendor.title+'</a></p><p class="mb-0">Punjab, India</p><p>ORDER '+val.id+'</p><p class="mb-0 small view-det"><a href="'+view_details+'">View Details</a></p></div><div class="ml-auto ord-com-btn"><p class="bg-success text-white py-1 px-2 rounded small mb-1">'+val.status+'</p><p class="small font-weight-bold text-center"><i class="feather-clock"></i>'+val.createdAt.toDate().toDateString()+'</p></div></div><div class="d-flex pt-3 m-d-flex"><div class="small">';
            var price = 0;
            for(let i = 0; i < val.products.length; i++) {
            	html = html+ '<p class="text- font-weight-bold mb-0">'+val.products[i]['name']+' x '+ val.products[i]['quantity']+'</p>';
            	price = price + val.products[i]['price'] * val.products[i]['quantity'];
            	  }
            html= html+ '<p class="text- font-weight-bold mb-0">'+price+'</p></div><div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br><span class="text-dark font-weight-bold">Total</span></div> <div class="text-right"><a href="checkout.html" class="btn btn-primary px-3">Reorder</a><a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a></div></div></div></div></div></div>';
        }
          });
    
          return html;      
}
 
function buildHTMLRejectedOrders(completedorderSnapshots){
        var html='';
        var alldata=[];
        var number= [];
        completedorderSnapshots.docs.forEach((listval) => {
            var datas=listval.data();
            alldata.push(datas);
        });
                
        alldata.forEach((listval) => {
            var val=listval;
            var order_id = val.id;
            var view_details = "<?php echo e(route('cancelled_order',':id')); ?>";
            view_details = view_details.replace(':id', 'id='+order_id);

            if(val.status == "Driver Rejected" || val.status == "Order Rejected"){
            html= html+'<div class="pb-3"><div class="p-3 rounded shadow-sm bg-white"><div class="d-flex border-bottom pb-3 m-d-flex"><div class="text-muted mr-3"><img alt="#" src="'+val.vendor.photo+'" class="img-fluid order_img rounded"></div><div><p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">'+val.vendor.title+'</a></p><p class="mb-0">Punjab, India</p><p>ORDER '+val.id+'</p><p class="mb-0 small view-det"><a href="'+view_details+'">View Details</a></p></div><div class="ml-auto ord-com-btn"><p class="bg-success text-white py-1 px-2 rounded small mb-1">'+val.status+'</p><p class="small font-weight-bold text-center"><i class="feather-clock"></i>'+val.createdAt.toDate().toDateString()+'</p></div></div><div class="d-flex pt-3 m-d-flex"><div class="small">';
            var price = 0;
            for(let i = 0; i < val.products.length; i++) {
            	html = html+ '<p class="text- font-weight-bold mb-0">'+val.products[i]['name']+' x '+ val.products[i]['quantity']+'</p>';
            	price = price + val.products[i]['price'] * val.products[i]['quantity'];
            	  }
            html= html+ '<p class="text- font-weight-bold mb-0">'+price+'</p></div><div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br><span class="text-dark font-weight-bold">Total</span></div> <div class="text-right"><a href="checkout.html" class="btn btn-primary px-3">Reorder</a><a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a></div></div></div></div></div></div>';
        }
          });
    
          return html;      
}

</script><?php /**PATH /home/foodie/public_html/website/resources/views/my_order/my_order.blade.php ENDPATH**/ ?>