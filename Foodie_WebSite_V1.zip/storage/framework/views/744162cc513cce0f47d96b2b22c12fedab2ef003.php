<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/slick/slick.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/slick/slick-theme.min.css')); ?>" />

<link href="<?php echo e(asset('vendor/icons/feather.css')); ?>" rel="stylesheet" type="text/css">

<link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('vendor/sidebar/demo.css')); ?>" rel="stylesheet"><?php /**PATH D:\php\htdocs\laravelpro\resources\views/home/include/stylesheet.blade.php ENDPATH**/ ?>