<nav id="main-nav">
<ul class="second-nav">
<li><a href="<?php echo e(url('/')); ?>"><i class="feather-home mr-2"></i> Homepage</a></li>
<li><a href="<?php echo e(url('my_order')); ?>"><i class="feather-list mr-2"></i> My Orders</a></li>
<li>
<a href="#"><i class="feather-edit-2 mr-2"></i> Authentication</a>
<ul>
	<?php if(auth()->guard()->check()): ?>
	  	<li><a href="#">Forgot Password</a></li>
	<?php else: ?>
	 	<li><a href="<?php echo e(url('login')); ?>">Login</a></li>
		<li><a href="<?php echo e(url('signup')); ?>">Register</a></li>
	<?php endif; ?>


<!-- <li><a href="<?php echo e(url('/verification')); ?>">Verification</a></li>
<li><a href="<?php echo e(url('/location')); ?>">Location</a></li> -->
</ul>
</li>
<!-- <li><a href="#"><i class="feather-heart mr-2"></i> Favorites</a></li>
<li><a href="#"><i class="feather-trending-up mr-2"></i> Trending</a></li>
<li><a href="#"><i class="feather-award mr-2"></i> Most Popular</a></li> -->
<!-- <li><a href="<?php echo e(url('/restaurant')); ?>"><i class="feather-paperclip mr-2"></i> Restaurant Detail</a></li> -->
<!-- <li><a href="#"><i class="feather-list mr-2"></i> Checkout</a></li> -->
<!-- <li><a href="<?php echo e(url('/successful')); ?>"><i class="feather-check-circle mr-2"></i> Successful</a></li> -->
<!-- <li><a href="<?php echo e(url('/map')); ?>"><i class="feather-map-pin mr-2"></i> Live Map</a></li> -->
<li>
<a href="#"><i class="feather-user mr-2"></i> Profile</a>
<ul>
<li><a href="#">Profile</a></li>
<!-- <li><a href="#">Delivery support</a></li> -->
<li><a href="<?php echo e(url('contact_us')); ?>">Contact Us</a></li>
<!-- <li><a href="#">Terms of use</a></li>
<li><a href="#">Privacy & Policy</a></li> -->
</ul>
</li>
<!-- <li>
<a href="#"><i class="feather-alert-triangle mr-2"></i> Error</a>
<ul>
<li><a href="<?php echo e(url('/not_found')); ?>">Not Found</a>
<li><a href="<?php echo e(url('/maintence')); ?>"> Maintence</a>
<li><a href="<?php echo e(url('/coming_soon')); ?>">Coming Soon</a>
</ul>
</li> -->
<!-- <li>
<a href="#"><i class="feather-link mr-2"></i> Navigation Link Example</a>
<ul>
<li>
<a href="#">Link Example 1</a>
<ul>
<li>
<a href="#">Link Example 1.1</a>
<ul>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
</ul>
</li>
<li>
<a href="#">Link Example 1.2</a>
<ul>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
<li><a href="#">Link</a></li>
</ul>
</li>
</ul>
</li>
<li><a href="#">Link Example 2</a></li>
<li><a href="#">Link Example 3</a></li>
<li><a href="#">Link Example 4</a></li>
<li data-nav-custom-content>
<div class="custom-message">
You can add any custom content to your navigation items. This text is just an example.
</div>
</li>
</ul>
</li>
</ul> -->
<ul class="bottom-nav">
<li class="email">
<a class="text-danger" href="<?php echo e(url('/')); ?>">
<p class="h5 m-0"><i class="feather-home text-danger"></i></p>
Home
</a>
</li>
<!-- <li class="github">
<a href="#">
<p class="h5 m-0"><i class="feather-message-circle"></i></p>
FAQ
</a>
</li> -->
<li class="ko-fi">
<a href="<?php echo e(url('contact_us')); ?>">
<p class="h5 m-0"><i class="feather-phone"></i></p>
Help
</a>
</li>
</ul>
</nav>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Filter</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body p-0">
<div class="siddhi-filter">
<div class="filter">

<div class="p-3 bg-light border-bottom">
<h6 class="m-0">SORT BY</h6>
</div>
<div class="custom-control border-bottom px-0  custom-radio">
<input type="radio" id="customRadio1f" name="location" class="custom-control-input" checked>
<label class="custom-control-label py-3 w-100 px-3" for="customRadio1f">Top Rated</label>
</div>
<div class="custom-control border-bottom px-0  custom-radio">
<input type="radio" id="customRadio2f" name="location" class="custom-control-input">
<label class="custom-control-label py-3 w-100 px-3" for="customRadio2f">Nearest Me</label>
</div>
<div class="custom-control border-bottom px-0  custom-radio">
<input type="radio" id="customRadio3f" name="location" class="custom-control-input">
<label class="custom-control-label py-3 w-100 px-3" for="customRadio3f">Cost High to Low</label>
</div>
<div class="custom-control border-bottom px-0  custom-radio">
<input type="radio" id="customRadio4f" name="location" class="custom-control-input">
<label class="custom-control-label py-3 w-100 px-3" for="customRadio4f">Cost Low to High</label>
</div>
<div class="custom-control border-bottom px-0  custom-radio">
<input type="radio" id="customRadio5f" name="location" class="custom-control-input">
<label class="custom-control-label py-3 w-100 px-3" for="customRadio5f">Most Popular</label>
</div>

<div class="p-3 bg-light border-bottom">
<h6 class="m-0">FILTER</h6>
</div>
<div class="custom-control border-bottom px-0  custom-checkbox">
<input type="checkbox" class="custom-control-input" id="defaultCheck1" checked>
<label class="custom-control-label py-3 w-100 px-3" for="defaultCheck1">Open Now</label>
</div>
<div class="custom-control border-bottom px-0  custom-checkbox">
<input type="checkbox" class="custom-control-input" id="defaultCheck2">
<label class="custom-control-label py-3 w-100 px-3" for="defaultCheck2">Credit Cards</label>
</div>
<div class="custom-control border-bottom px-0  custom-checkbox">
<input type="checkbox" class="custom-control-input" id="defaultCheck3">
<label class="custom-control-label py-3 w-100 px-3" for="defaultCheck3">Alcohol Served</label>
</div>

<div class="p-3 bg-light border-bottom">
<h6 class="m-0">ADDITIONAL FILTERS</h6>
</div>
<div class="px-3 pt-3">
<input type="range" class="custom-range" min="0" max="100" name="minmax">
<div class="form-row">
<div class="form-group col-6">
<label>Min</label>
<input class="form-control" placeholder="$0" type="number">
</div>
<div class="form-group text-right col-6">
<label>Max</label>
<input class="form-control" placeholder="$1,0000" type="number">
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal-footer p-0 border-0">
<div class="col-6 m-0 p-0">
<button type="button" class="btn border-top btn-lg btn-block" data-dismiss="modal">Close</button>
</div>
<div class="col-6 m-0 p-0">
<button type="button" class="btn btn-primary btn-lg btn-block">Apply</button>
</div>
</div>
</div>
</div>
</div><?php /**PATH /home/foodie/public_html/website/resources/views/layouts/nav.blade.php ENDPATH**/ ?>