<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="osahan-checkout">


<div class="container position-relative">
<div class="py-5 row">
<div class="col-md-12 mb-3">
<div>

<div class="osahan-cart-item mb-3 rounded shadow-sm bg-white overflow-hidden">
<div class="osahan-cart-item-profile bg-white p-3">
<div class="card card-default">
    
    <?php $authorName=@$cart['cart_order']['authorName']; ?>

    <?php if($message = Session::get('success')): ?>
        <div class="py-5 linus-coming-soon d-flex justify-content-center align-items-center">
            <div class="col-md-6">
            <div class="text-center pb-3">
            <h1 class="font-weight-bold"><?php if(@$authorName){ echo @$authorName.","; } ?> Your order has been successful</h1>
            <p>Check your order status in <a href="my_order.html" class="font-weight-bold text-decoration-none text-primary">My Orders</a> about next steps information.</p>
            </div>

            <div class="bg-white rounded text-center p-4 shadow-sm">
            <h1 class="display-1 mb-4">🎉</h1>
            <h6 class="font-weight-bold mb-2">Preparing your order</h6>
            <p class="small text-muted">Your order will be prepared and will come soon</p>
            <a href="<?php echo e(route('my_order')); ?>" class="btn rounded btn-primary btn-lg btn-block">View Order</a>
            </div>
            </div>
        </div>

    <?php endif; ?>
</div>
</div>
</div>


</div>
</div>
</div>

</div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($message = Session::get('success')): ?>     
    <script src="https://unpkg.com/geofirestore/dist/geofirestore.js"></script>
<script type="text/javascript">
    
    var id_order = "<?php echo uniqid();?>";
    var userId =  "<?php echo $id; ?>";
    var userDetailsRef= database.collection('users').where('id',"==",userId);
    var vendorDetailsRef= database.collection('vendors');
    var AdminCommission = database.collection('settings').doc('AdminCommission');
    var razorpaySettings = database.collection('settings').doc('razorpaySettings');
    var geoFirestore = new GeoFirestore(firestore);

        
        <?php if(@$cart['payment_status']==true && !empty(@$cart['cart_order']['order_json'])){ ?>

        finalCheckout();
        
        function finalCheckout() {
        userDetailsRef.get().then( async function(userSnapshots){
            
            var userDetails = userSnapshots.docs[0].data();
            
            var order_json='<?php echo json_encode($cart['cart_order']['order_json']); ?>';
            order_json=JSON.parse(order_json);
            payment_method='<?php echo $payment_method; ?>';
            console.log(payment_method);
            var vendorID=order_json.vendorID;
            vendorDetailsRef.where('id',"==",vendorID).get().then( async function(vendorSnapshots){
            var vendorDetails=vendorSnapshots.docs[0].data();
            
            var createdAt= firebase.firestore.FieldValue.serverTimestamp();
            database.collection('restaurant_orders').doc(id_order).set({'address':userDetails.shippingAddress,'author':userDetails,'authorID':order_json.authorID,'couponCode':order_json.couponCode,'couponId':order_json.couponId,"createdAt":createdAt,'id':id_order,'products':order_json.products,'status':order_json.status,'vendor':vendorDetails,'vendorID':vendorDetails.id,'delivery_charge':order_json.delivery_charge,'tip_amount':order_json.tip_amount,'adminCommission':order_json.adminCommission,'payment_method':payment_method,'take_away':order_json.take_away}).then(function(result) {
                         
                         $.ajax({
                           type:'POST',
                           url:"<?php echo route('order-complete'); ?>",
                           data:{_token:'<?php echo csrf_token() ?>'},
                           success:function(data) {
                               data=JSON.parse(data);
                               
                               
                           }
                        }); 

            });
            
            }); 
        });
    } 
<?php } ?>
    </script>
    
<?php endif; ?><?php /**PATH /home/foodie/public_html/website/resources/views/checkout/success.blade.php ENDPATH**/ ?>