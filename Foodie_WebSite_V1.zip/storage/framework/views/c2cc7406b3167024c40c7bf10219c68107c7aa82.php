<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from askbootstrap.com/preview/swiggiweb/location.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 Jan 2022 10:58:53 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Askbootstrap">
<meta name="author" content="Askbootstrap">
<link rel="icon" type="image/png" href="img/fav.png">
<title>Swiggiweb - Online Food Ordering Website Template</title>

<link rel="stylesheet" type="text/css" href="vendor/slick/slick.min.css" />
<link rel="stylesheet" type="text/css" href="vendor/slick/slick-theme.min.css" />

<link href="vendor/icons/feather.css" rel="stylesheet" type="text/css">

<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<link href="css/style.css" rel="stylesheet">

<link href="vendor/sidebar/demo.css" rel="stylesheet">
</head>
<body class="bg-white">

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-none">
<div class="bg-primary border-bottom p-3 d-flex align-items-center mb-4">
<a class="toggle togglew toggle-2" href="#"><span></span></a>
<h4 class="font-weight-bold m-0 text-white">Location</h4>
</div>
</div>
<div class="location-page container">
<div class="d-flex align-items-center justify-content-center flex-column py-5">
<img alt="#" src="<?php echo e(asset('img/location.png')); ?>" class="img-fluid" alt="Responsive image">
<div class="px-4 text-center mt-4">
<h5 class="text-dark">Hi, nice to meet you!</h5>
<p class="mb-5">Choose your location to start find restaurants around you.</p>
<a href="home.html" class="btn btn-lg btn-primary btn-block my-4"><i class="feather-navigation"></i> Use current location</a>
</div>
</div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="osahan-menu-fotter fixed-bottom bg-white px-3 py-2 text-center d-none">
<div class="row">
<div class="col selected">
 <a href="home.html" class="text-danger small font-weight-bold text-decoration-none">
<p class="h4 m-0"><i class="feather-home text-danger"></i></p>
Home
</a>
</div>
<div class="col">
<a href="most_popular.html" class="text-dark small font-weight-bold text-decoration-none">
<p class="h4 m-0"><i class="feather-map-pin"></i></p>
Trending
</a>
</div>
<div class="col bg-white rounded-circle mt-n4 px-3 py-2">
<div class="bg-danger rounded-circle mt-n0 shadow">
<a href="checkout.html" class="text-white small font-weight-bold text-decoration-none">
<i class="feather-shopping-cart"></i>
</a>
</div>
</div>
<div class="col">
<a href="favorites.html" class="text-dark small font-weight-bold text-decoration-none">
<p class="h4 m-0"><i class="feather-heart"></i></p>
Favorites
</a>
</div>
<div class="col">
<a href="profile.html" class="text-dark small font-weight-bold text-decoration-none">
<p class="h4 m-0"><i class="feather-user"></i></p>
Profile
</a>
</div>
</div>
</div>

<script type="beab216e9dfbb36618c3170e-text/javascript" src="vendor/jquery/jquery.min.js"></script>
<script type="beab216e9dfbb36618c3170e-text/javascript" src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script type="beab216e9dfbb36618c3170e-text/javascript" src="vendor/slick/slick.min.js"></script>

<script type="beab216e9dfbb36618c3170e-text/javascript" src="vendor/sidebar/hc-offcanvas-nav.js"></script>

<script type="beab216e9dfbb36618c3170e-text/javascript" src="js/osahan.js"></script>
<script src="js/rocket-loader.min.js" data-cf-settings="beab216e9dfbb36618c3170e-|49" defer=""></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6c83f3d3890c41ab","version":"2021.12.0","r":1,"token":"dd471ab1978346bbb991feaa79e6ce5c","si":100}' crossorigin="anonymous"></script>
</body>

<!-- Mirrored from askbootstrap.com/preview/swiggiweb/location.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 Jan 2022 10:58:53 GMT -->
</html><?php /**PATH D:\php\htdocs\laravelpro\resources\views/location\location.blade.php ENDPATH**/ ?>