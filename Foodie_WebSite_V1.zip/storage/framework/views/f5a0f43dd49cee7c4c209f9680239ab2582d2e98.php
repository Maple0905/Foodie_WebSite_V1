<script type="490cf4da05ddb33bf38d2254-text/javascript" src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script type="490cf4da05ddb33bf38d2254-text/javascript" src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script type="490cf4da05ddb33bf38d2254-text/javascript" src="<?php echo e(asset('vendor/slick/slick.min.js')); ?>"></script>

<script type="490cf4da05ddb33bf38d2254-text/javascript" src="<?php echo e(asset('vendor/sidebar/hc-offcanvas-nav.js')); ?>"></script>

<script type="490cf4da05ddb33bf38d2254-text/javascript" src="<?php echo e(asset('js/osahan.js')); ?>"></script>
<script src="<?php echo e(asset('js/rocket-loader.min.js')); ?>" data-cf-settings="490cf4da05ddb33bf38d2254-|49" defer=""></script><script defer src="<?php echo e(asset('https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194')); ?>" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6c83f34ffe560fee","version":"2021.12.0","r":1,"token":"dd471ab1978346bbb991feaa79e6ce5c","si":100}' crossorigin="anonymous"></script><?php /**PATH D:\php\htdocs\laravelpro\resources\views/home/include/script.blade.php ENDPATH**/ ?>